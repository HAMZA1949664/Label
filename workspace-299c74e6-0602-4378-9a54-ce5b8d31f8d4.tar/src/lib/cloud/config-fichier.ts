/**
 * Lecteur du fichier de configuration « cloud.config.json » (racine du projet)
 * — Clément Design, Étiquettes & colisage.
 *
 * RÔLE : ce fichier est LA source de vérité de l'installation. Il est relu
 * côté serveur uniquement (jamais envoyé au navigateur) toutes les 5 secondes :
 * Clément peut modifier la connexion Supabase ou les comptes sans toucher au
 * code, et les façonniers n'ont strictement rien à saisir ni à modifier.
 *
 * Contenu attendu (cf. cloud.config.json à la racine) :
 *  - supabaseUrl / supabaseCle : connexion au projet Supabase partagé ;
 *  - secretSession             : phrase secrète des cookies de session ;
 *  - comptes[]                 : accès (identifiant, code, nom, rôle, site).
 *
 * Tolérance : si le fichier est absent ou illisible, l'application retombe
 * proprement sur le comportement historique (connexion saisie dans l'interface
 * + aucun compte) — aucune fonctionnalité existante n'est cassée.
 */

import { readFile } from "node:fs/promises";
import path from "node:path";

/** Rôle d'un compte : 'faconnier' (génération) ou 'france' (accès complet). */
export type RoleCompte = "faconnier" | "france";

/** Compte tel que défini dans cloud.config.json (contient le code — serveur). */
export interface CompteConfig {
  identifiant: string;
  code: string;
  nom: string;
  role: RoleCompte;
  siteId: string;
  siteLabel: string;
}

/** Configuration lue dans le fichier (valeurs brutes, secrets inclus). */
export interface ConfigFichier {
  /** Vrai si le fichier existe et est du JSON valide. */
  present: boolean;
  /** Message FR si le fichier existe mais est illisible (affiché à Clément). */
  erreur: string | null;
  supabaseUrl: string; // '' si absent
  supabaseCle: string; // '' si absent
  secretSession: string; // '' si absent
  comptes: CompteConfig[]; // [] si absent → authentification désactivée
}

const NOM_FICHIER = "cloud.config.json";
const DUREE_CACHE_MS = 5_000;

let cache: { valeur: ConfigFichier; expire: number } | null = null;

/** Invalide le cache (utile après édition dans le même process). */
export function invaliderCacheConfigFichier(): void {
  cache = null;
}

/** Vide (comportement historique, auth désactivée). */
function vide(erreur: string | null = null): ConfigFichier {
  return {
    present: false,
    erreur,
    supabaseUrl: "",
    supabaseCle: "",
    secretSession: "",
    comptes: [],
  };
}

/** Normalise et filtre la liste des comptes (tolérant aux erreurs de saisie). */
function validerComptes(brut: unknown): CompteConfig[] {
  if (!Array.isArray(brut)) return [];
  const comptes: CompteConfig[] = [];
  const vus = new Set<string>();
  for (const c of brut as Record<string, unknown>[]) {
    const identifiant =
      typeof c?.identifiant === "string" ? c.identifiant.trim().toLowerCase() : "";
    const code = typeof c?.code === "string" ? c.code.trim() : "";
    const nom = typeof c?.nom === "string" ? c.nom.trim() : "";
    const role: RoleCompte = c?.role === "france" ? "france" : "faconnier";
    const siteId = typeof c?.siteId === "string" ? c.siteId.trim().toLowerCase() : "";
    const siteLabel = typeof c?.siteLabel === "string" ? c.siteLabel.trim() : "";
    if (!identifiant || !code || !nom || !siteId || !siteLabel) {
      console.warn(`${NOM_FICHIER} : compte incomplet ignoré.`);
      continue;
    }
    if (code.length < 4) {
      console.warn(
        `${NOM_FICHIER} : code trop court pour « ${identifiant} » (4 caractères minimum) — compte ignoré.`
      );
      continue;
    }
    if (!/^[a-z0-9-]{1,40}$/.test(siteId)) {
      console.warn(
        `${NOM_FICHIER} : siteId invalide pour « ${identifiant} » (a-z, 0-9, tirets) — compte ignoré.`
      );
      continue;
    }
    if (vus.has(identifiant)) {
      console.warn(`${NOM_FICHIER} : identifiant dupliqué « ${identifiant} » — doublon ignoré.`);
      continue;
    }
    vus.add(identifiant);
    comptes.push({ identifiant, code, nom, role, siteId, siteLabel });
  }
  return comptes;
}

/**
 * Lit cloud.config.json (cache 5 s). Ne lève JAMAIS d'exception : en cas de
 * problème, retourne une config vide avec un message d'erreur exploitable.
 */
export async function lireConfigFichier(): Promise<ConfigFichier> {
  if (cache && cache.expire > Date.now()) return cache.valeur;
  try {
    const brut = await readFile(path.join(process.cwd(), NOM_FICHIER), "utf8");
    try {
      const json = JSON.parse(brut) as Record<string, unknown>;
      const cfg: ConfigFichier = {
        present: true,
        erreur: null,
        supabaseUrl:
          typeof json.supabaseUrl === "string"
            ? json.supabaseUrl.trim().replace(/\/+$/, "")
            : "",
        supabaseCle: typeof json.supabaseCle === "string" ? json.supabaseCle.trim() : "",
        secretSession:
          typeof json.secretSession === "string" ? json.secretSession.trim() : "",
        comptes: validerComptes(json.comptes),
      };
      cache = { valeur: cfg, expire: Date.now() + DUREE_CACHE_MS };
      return cfg;
    } catch (e) {
      const message = `${NOM_FICHIER} est illisible (JSON invalide) : corrigez le fichier à la racine du projet. Détail : ${
        e instanceof Error ? e.message : String(e)
      }`;
      console.error(message);
      cache = { valeur: vide(message), expire: Date.now() + DUREE_CACHE_MS };
      return cache.valeur;
    }
  } catch {
    // Fichier absent : comportement historique (aucun bruit dans les logs —
    // c'est une installation sans authentification, tout à fait valide).
    cache = { valeur: vide(null), expire: Date.now() + DUREE_CACHE_MS };
    return cache.valeur;
  }
}
