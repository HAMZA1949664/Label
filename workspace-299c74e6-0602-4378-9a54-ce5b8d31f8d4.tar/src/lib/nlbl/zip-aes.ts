/**
 * Générateur d'archives ZIP avec chiffrement WinZip AES (spécification AE-1 / AE-2).
 *
 * Le format de fichier .nlbl de Zebra Designer 3 est une archive ZIP dont chaque
 * entrée est chiffrée en AES (méthode 99 + champ supplémentaire 0x9901), avec un
 * mot de passe fixe propre au format. Ce module reproduit fidèlement la structure
 * produite par Zebra Designer (AES-256, AE-1, deflate, CRC32 réel).
 *
 * Implémentation volontairement sans dépendance externe : crypto (PBKDF2-HMAC-SHA1,
 * AES-CTR, HMAC-SHA1) + zlib (deflate) suffisent, conformément à la spécification
 * WinZip AES https://www.winzip.com/en/support/aes-tips/
 */

import { deflateRawSync } from "zlib";
import { pbkdf2Sync, randomBytes, createHmac, createCipheriv } from "crypto";

/** Force AES supportée : 1 = AES-128, 2 = AES-192, 3 = AES-256 (taille de clé en octets). */
export type AesStrength = 1 | 2 | 3;

const AES_KEY_SIZES: Record<AesStrength, number> = { 1: 16, 2: 24, 3: 32 };
/** Taille du sel = moitié de la taille de clé AES (spécification WinZip AES). */
const AES_SALT_SIZES: Record<AesStrength, number> = { 1: 8, 2: 12, 3: 16 };
const PBKDF2_ITERATIONS = 1000;
const HMAC_AUTH_CODE_LENGTH = 10;

export interface ZipAesOptions {
  /** Mot de passe de chiffrement (obligatoire pour chiffrer l'entrée). */
  password: string;
  /** Force AES, AES-256 par défaut (comme Zebra Designer). */
  strength?: AesStrength;
}

export interface ZipEntryInput {
  /** Nom de l'entrée dans l'archive (ASCII de préférence). */
  name: string;
  /** Contenu non compressé. */
  data: Buffer | string;
  /** Date de modification (défaut : maintenant). */
  modified?: Date;
  /** Si défini : entrée chiffrée WinZip AES. Si absent : entrée deflate non chiffrée. */
  aes?: ZipAesOptions;
}

// ---------------------------------------------------------------------------
// CRC32 (polynôme 0xEDB88320)
// ---------------------------------------------------------------------------
const CRC_TABLE: Uint32Array = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

// ---------------------------------------------------------------------------
// Horodatage DOS
// ---------------------------------------------------------------------------
function dosDateTime(d: Date): { time: number; date: number } {
  const time =
    (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const date =
    (((d.getFullYear() - 1980) & 0x7f) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

// ---------------------------------------------------------------------------
// Chiffrement WinZip AES (AE-1)
// ---------------------------------------------------------------------------
interface Ae1Result {
  /** salt | motDePasseVérif | donnéesChiffrées | codeAuthentification */
  blob: Buffer;
  strength: AesStrength;
  /** Méthode de compression réelle (8 = deflate). */
  method: number;
}

/**
 * Chiffrement AES-CTR avec compteur 128 bits PETIT-BOUTIEN initialisé à 1,
 * conformément à l'implémentation WinZip AES utilisée par Zebra Designer
 * (keystream = AES-ECB(blocCompteur) XOR données).
 */
function chiffrerCtr(aesKey: Buffer, data: Buffer): Buffer {
  const nbBlocs = Math.ceil(data.length / 16);
  const ecb = createCipheriv(`aes-${aesKey.length * 8}-ecb`, aesKey, null);
  ecb.setAutoPadding(false);

  const keystream = Buffer.alloc(nbBlocs * 16);
  for (let i = 0; i < nbBlocs; i++) {
    const blocCompteur = Buffer.alloc(16);
    blocCompteur.writeBigUInt64LE(BigInt(i + 1), 0); // compteur petit-boutien à partir de 1
    keystream.set(ecb.update(blocCompteur), i * 16);
  }
  ecb.final();

  const sortie = Buffer.from(data);
  for (let i = 0; i < data.length; i++) sortie[i] ^= keystream[i];
  return sortie;
}

/**
 * Chiffre des données (déjà compressées) selon WinZip AES tel que produit par
 * Zebra Designer 3 (vérifié sur le template original) :
 * - sel de taille clé/2, clés dérivées : PBKDF2-HMAC-SHA1(motDePasse, sel, 1000 itérations)
 * - chiffrement : AES-CTR, compteur 128 bits petit-boutien initialisé à 1
 * - authentification : HMAC-SHA1 sur les données chiffrées seules (10 premiers octets)
 */
function encryptAe1(compressed: Buffer, password: string, strength: AesStrength): Ae1Result {
  const keySize = AES_KEY_SIZES[strength];
  const salt = randomBytes(AES_SALT_SIZES[strength]);
  const derived = pbkdf2Sync(
    Buffer.from(password, "utf-8"),
    salt,
    PBKDF2_ITERATIONS,
    keySize * 2 + 2, // clé AES + clé HMAC + 2 octets de vérification
    "sha1"
  );

  const aesKey = derived.subarray(0, keySize);
  const hmacKey = derived.subarray(keySize, keySize * 2);
  const passwordVerification = derived.subarray(keySize * 2, keySize * 2 + 2);

  const ciphertext = chiffrerCtr(aesKey, compressed);

  const hmac = createHmac("sha1", hmacKey);
  hmac.update(ciphertext);
  const authCode = hmac.digest().subarray(0, HMAC_AUTH_CODE_LENGTH);

  return {
    blob: Buffer.concat([salt, passwordVerification, ciphertext, authCode]),
    strength,
    method: 8, // méthode de compression réelle déclarée dans le champ AES
  };
}

/** Champ supplémentaire WinZip AES (ID 0x9901) : version AE-1, "AE", force, méthode réelle. */
function aesExtraField(strength: AesStrength, realMethod: number): Buffer {
  const field = Buffer.alloc(11);
  field.writeUInt16LE(0x9901, 0); // ID du champ
  field.writeUInt16LE(7, 2); // taille des données
  field.writeUInt16LE(0x0001, 4); // version 1 = AE-1 (CRC32 réel présent)
  field.write("AE", 6, "ascii"); // fournisseur
  field.writeUInt8(strength, 8); // force (3 = AES-256)
  field.writeUInt16LE(realMethod, 9); // méthode de compression réelle
  return field;
}

// ---------------------------------------------------------------------------
// Assemblage de l'archive
// ---------------------------------------------------------------------------
function writeLocalHeader(
  nameBuf: Buffer,
  extra: Buffer,
  flags: number,
  method: number,
  { time, date }: { time: number; date: number },
  crc: number,
  compressedSize: number,
  uncompressedSize: number
): Buffer {
  const header = Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50, 0); // signature
  header.writeUInt16LE(20, 4); // version minimale requise (2.0, comme Zebra Designer)
  header.writeUInt16LE(flags, 6);
  header.writeUInt16LE(method, 8);
  header.writeUInt16LE(time, 10);
  header.writeUInt16LE(date, 12);
  header.writeUInt32LE(crc, 14);
  header.writeUInt32LE(compressedSize, 18);
  header.writeUInt32LE(uncompressedSize, 22);
  header.writeUInt16LE(nameBuf.length, 26);
  header.writeUInt16LE(extra.length, 28);
  return Buffer.concat([header, nameBuf, extra]);
}

function writeCentralHeader(
  nameBuf: Buffer,
  extra: Buffer,
  offset: number,
  flags: number,
  method: number,
  { time, date }: { time: number; date: number },
  crc: number,
  compressedSize: number,
  uncompressedSize: number
): Buffer {
  const header = Buffer.alloc(46);
  header.writeUInt32LE(0x02014b50, 0); // signature
  header.writeUInt16LE(45, 4); // version de création (4.5, système FAT comme Zebra Designer)
  header.writeUInt16LE(20, 6); // version minimale requise
  header.writeUInt16LE(flags, 8);
  header.writeUInt16LE(method, 10);
  header.writeUInt16LE(time, 12);
  header.writeUInt16LE(date, 14);
  header.writeUInt32LE(crc, 16);
  header.writeUInt32LE(compressedSize, 20);
  header.writeUInt32LE(uncompressedSize, 24);
  header.writeUInt16LE(nameBuf.length, 28);
  header.writeUInt16LE(extra.length, 30);
  header.writeUInt16LE(0, 32); // longueur commentaire
  header.writeUInt16LE(0, 34); // numéro disque
  header.writeUInt16LE(0, 36); // attributs internes
  header.writeUInt32LE(0, 38); // attributs externes
  header.writeUInt32LE(offset, 42); // décalage de l'en-tête local
  return Buffer.concat([header, nameBuf, extra]);
}

/**
 * Construit une archive ZIP complète (en-têtes locaux + répertoire central + EOCD).
 * Chaque entrée dont `aes` est défini est chiffrée WinZip AES ; les autres sont
 * simplement compressées en deflate.
 */
export function buildZip(entries: ZipEntryInput[]): Buffer {
  const parts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBuf = Buffer.from(entry.name, "utf-8");
    const raw = Buffer.isBuffer(entry.data) ? entry.data : Buffer.from(entry.data, "utf-8");
    const modified = entry.modified ?? new Date();
    const dt = dosDateTime(modified);
    const crc = crc32(raw);

    let flags = 0;
    let method: number;
    let extra = Buffer.alloc(0);
    let stored: Buffer;

    if (entry.aes) {
      // 1. Compression deflate brute, 2. puis chiffrement AES
      const compressed = deflateRawSync(raw, { level: 9 });
      const strength = entry.aes.strength ?? 3;
      const encrypted = encryptAe1(compressed, entry.aes.password, strength);
      flags = 0x0001; // bit « chiffré »
      method = 99; // méthode AES
      extra = aesExtraField(strength, encrypted.method);
      stored = encrypted.blob;
    } else {
      const compressed = deflateRawSync(raw, { level: 9 });
      method = 8;
      stored = compressed;
    }

    const local = writeLocalHeader(
      nameBuf,
      extra,
      flags,
      method,
      dt,
      crc,
      stored.length,
      raw.length
    );
    parts.push(local, stored);

    centralParts.push(
      writeCentralHeader(
        nameBuf,
        extra,
        offset,
        flags,
        method,
        dt,
        crc,
        stored.length,
        raw.length
      )
    );

    offset += local.length + stored.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // signature fin de répertoire
  eocd.writeUInt16LE(0, 4); // numéro disque
  eocd.writeUInt16LE(0, 6); // disque du répertoire central
  eocd.writeUInt16LE(entries.length, 8); // entrées sur ce disque
  eocd.writeUInt16LE(entries.length, 10); // total entrées
  eocd.writeUInt32LE(centralDirectory.length, 12); // taille du répertoire
  eocd.writeUInt32LE(offset, 16); // décalage du répertoire
  eocd.writeUInt16LE(0, 20); // longueur commentaire

  return Buffer.concat([...parts, centralDirectory, eocd]);
}
