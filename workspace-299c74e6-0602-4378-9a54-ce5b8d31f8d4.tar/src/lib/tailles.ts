/**
 * Tri logique des tailles — du plus petit au plus grand.
 *
 * Le stock (base de données) mélange plusieurs familles de tailles :
 * - tailles uniques : U, TU
 * - bébé : BEBE
 * - tranches d'âge : 3-4 A, 5-6 A, 10-12
 * - tailles littérales : XS, S, M, L, XL, XXL, 2XL, 3XL, XXXL, 4XL, 5XL, M+
 * - tailles numériques : 34, 36 … 64 (avec ou sans préfixe T : T0, T46)
 * - tailles spéciales : SPE- (petit format), SPE+ (grand format)
 *
 * Un tri alphabétique donnerait XXL < XL < S — absurde en atelier.
 * `comparerTailles` établit un ordre total : d'abord par famille
 * (taille unique → bébé → âge → littérales → numériques → spéciales),
 * puis par valeur croissante à l'intérieur de chaque famille.
 */

/** Paires littérales classées du plus petit au plus grand. */
const ORDRE_LITTERRALES: string[] = [
  "XS", "S", "M", "M+", "L", "XL", "XXL", "2XL", "3XL", "XXXL", "4XL", "5XL", "6XL",
];

/** Rang d'une taille littérale (insensible à la casse, espaces tolérés). */
function rangLitterale(s: string): number | null {
  const cle = s.toUpperCase().replace(/\s+/g, "");
  const idx = ORDRE_LITTERRALES.indexOf(cle);
  return idx === -1 ? null : idx;
}

interface Classement {
  /** Famille : 0 = taille unique, 1 = bébé, 2 = âge, 3 = littérale, 4 = numérique, 5 = spéciale, 6 = autre. */
  famille: number;
  /** Valeur de tri à l'intérieur de la famille. */
  valeur: number;
  /** Ordre alphabétique de secours (famille « autre »). */
  texte: string;
}

/** Décompose une taille en (famille, valeur) pour un ordre total. */
function classer(taille: string): Classement {
  const s = String(taille).trim();

  // Taille unique
  if (/^(U|TU|OS|UNIQUE)$/i.test(s)) return { famille: 0, valeur: 0, texte: s };

  // Bébé
  if (/^BEBE$/i.test(s)) return { famille: 1, valeur: 0, texte: s };

  // Tranche d'âge : « 3-4 A », « 5-6A », « 10-12 » — tri par l'âge de départ
  const age = s.match(/^(\d+)\s*-\s*\d+\s*A?$/i);
  if (age) return { famille: 2, valeur: Number(age[1]), texte: s };

  // Tailles littérales (XS, S, M, M+, L, XL, XXL, 3XL, 4XL…)
  const litterale = rangLitterale(s);
  if (litterale !== null) return { famille: 3, valeur: litterale, texte: s };

  // Numériques : T0, T46, 46 — tri par le nombre
  const nombre = s.match(/^(?:T)?(\d+)$/i);
  if (nombre) return { famille: 4, valeur: Number(nombre[1]), texte: s };

  // Spéciales : SPE- (avant) puis SPE+ (après)
  if (/^SPE-$/i.test(s)) return { famille: 5, valeur: 0, texte: s };
  if (/^SPE\+$/i.test(s)) return { famille: 5, valeur: 1, texte: s };

  // Inconnu : regroupé à la fin, ordre alphabétique stable
  return { famille: 6, valeur: 0, texte: s };
}

/**
 * Compare deux tailles du plus petit au plus grand.
 * Retourne < 0, 0 ou > 0 (compatible Array.prototype.sort).
 */
export function comparerTailles(a: string, b: string): number {
  const ca = classer(a);
  const cb = classer(b);
  if (ca.famille !== cb.famille) return ca.famille - cb.famille;
  if (ca.valeur !== cb.valeur) return ca.valeur - cb.valeur;
  // Dernier recours : alphabétique FR, numérique pour les suites de chiffres
  return ca.texte.localeCompare(cb.texte, "fr", { numeric: true, sensitivity: "base" });
}

/**
 * Trie une liste de tailles du plus petit au plus grand (copie, entrée intacte).
 * Les doublons sont conservés — penser à dédupliquer avant l'appel si besoin.
 */
export function trierTailles(tailles: Iterable<string>): string[] {
  return [...tailles].sort(comparerTailles);
}
