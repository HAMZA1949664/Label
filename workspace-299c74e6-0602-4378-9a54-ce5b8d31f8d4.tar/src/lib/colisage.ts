/**
 * Colisage — logique partagée client/serveur (aucune API Node).
 *
 * Principe métier : un opérateur scanne à la douchette les codes-barres des
 * pièces finies (3 000 à 4 000 lignes). Chaque code est retrouvé dans la base
 * (catalogue FAB, ou code SPE décodé côté serveur), puis les lignes sont
 * regroupées automatiquement : OF → modèle → couleur → taille, avec comptage
 * des occurrences (un code rescanné = une pièce de plus).
 */

import { comparerTailles } from "./tailles";

/** Une ligne du colisage regroupé. */
export interface LigneColisage {
  /** N° d'OF identifié (chaîne vide = non identifiable, ex. code FAB). */
  of: string;
  /** Modèle complet comme sur l'étiquette, ex. « FIRENZE ML » / « ADDICT MC SPE ». */
  modele: string;
  /** Libellé français de la couleur, ex. « Blanc ». */
  couleur: string;
  /** Code couleur du stock, ex. « BLC ». */
  couleurCode: string;
  /** Taille compacte française, ex. « T46 », « XS », « TU ». */
  taille: string;
  /** Libellé français de la manche (vide si sans objet). */
  manche: string;
  /** Nombre de pièces comptées pour cette ligne. */
  quantite: number;
}

/** Un code-barres non reconnu, avec son nombre d'occurrences. */
export interface CodeInconnu {
  code: string;
  quantite: number;
}

/** Résultat complet d'un colisage. */
export interface ResultatColisage {
  lignes: LigneColisage[];
  inconnus: CodeInconnu[];
  stats: {
    /** Nombre total de codes reçus (doublons compris). */
    total: number;
    /** Codes reconnus dans la base. */
    reconnus: number;
    /** Quantité de codes inconnus (occurrences cumulées). */
    inconnusQuantite: number;
    /** Nombre de lignes distinctes du colisage. */
    skus: number;
    /** Nombre d'OF distincts identifiés. */
    ofs: number;
    /** Quantité totale de pièces reconnues (somme des quantités). */
    quantite: number;
    /** Durée de traitement côté serveur (ms) — indicative. */
    dureeMs: number;
  };
}

/** Corps de la requête POST /api/colisage. */
export interface RequeteColisage {
  /** Codes-barres scannés (13 chiffres), doublons autorisés. */
  codes: string[];
  /** N° d'OF additionnels fournis par l'opérateur (aide au décodage SPE). */
  ofs?: string[];
}

/** Plafond de sécurité : nombre maximal de codes traités par requête. */
export const MAX_CODES_COLISAGE = 20000;

/** Plafond du champ « texte collé » (≈ 300 000 codes, marge large). */
export const TAILLE_MAX_TEXTE_COLISAGE = 2_000_000;

/**
 * Extrait tous les codes-barres EAN-13 (13 chiffres isolés) d'un texte collé
 * ou d'un fichier importé. Tolère les exportations multi-colonnes, les
 * séparateurs (tabulation, point-virgule…) et les lignes vides : la même
 * logique que l'outil d'origine. Les doublons sont conservés (une pièce
 * rescannée doit être comptée).
 */
export function extraireCodes(texte: string): string[] {
  if (!texte) return [];
  const correspondances = texte.match(/(?<!\d)\d{13}(?!\d)/g);
  return correspondances ? correspondances : [];
}

/** Ordre logique des manches (petites lignes de production d'abord). */
const ORDRE_MANCHES = ["", "Longues / Long", "Courtes / Short", "3/4 / 3/4"];

function rangManche(m: string): number {
  const idx = ORDRE_MANCHES.indexOf(m);
  return idx === -1 ? ORDRE_MANCHES.length : idx;
}

/**
 * Trie les lignes d'un colisage : OF (croissant, « non identifié » en dernier)
 * → modèle → couleur → manche → taille (ordre logique du plus petit au plus
 * grand). Ne modifie pas le tableau reçu.
 */
export function trierLignesColisage<T extends LigneColisage>(lignes: T[]): T[] {
  return [...lignes].sort((a, b) => {
    // OF connus d'abord, ordre numérique naturel (078594 < 078910)
    if (a.of !== b.of) {
      if (!a.of) return 1;
      if (!b.of) return -1;
      return a.of.localeCompare(b.of, "fr", { numeric: true });
    }
    if (a.modele !== b.modele) return a.modele.localeCompare(b.modele, "fr", { sensitivity: "base" });
    if (a.couleur !== b.couleur) return a.couleur.localeCompare(b.couleur, "fr", { sensitivity: "base" });
    if (a.manche !== b.manche) return rangManche(a.manche) - rangManche(b.manche);
    return comparerTailles(a.taille, b.taille);
  });
}

/** Horodatage Paris AAAAMMJJ_HHmm pour les noms de fichiers exportés. */
export function horodatageFichier(d = new Date()): string {
  const h = new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(d);
  const p = (type: string) => h.find((x) => x.type === type)?.value ?? "";
  return `${p("year")}${p("month")}${p("day")}_${p("hour")}${p("minute")}`;
}

const CSV_HEADERS = ["OF", "Modele", "Couleur", "Taille", "Quantite", "Manche"];

/** Échappe une valeur CSV (séparateur ; — guillemets si nécessaire). */
function champCsv(v: string | number): string {
  const s = String(v);
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Construit le contenu CSV (séparateur ; + BOM UTF-8 pour Excel FR). */
export function construireCsvColisage(lignes: LigneColisage[]): string {
  const rows = lignes.map((l) =>
    [l.of || "-", l.modele, l.couleur, l.taille, l.quantite, l.manche]
      .map(champCsv)
      .join(";")
  );
  return "\uFEFF" + [CSV_HEADERS.join(";"), ...rows].join("\r\n") + "\r\n";
}
