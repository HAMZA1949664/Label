/**
 * Données et calculs métier du générateur d'étiquettes.
 * Reproduit fidèlement la logique du module d'origine (etiquettes.html) :
 * correspondances couleurs/manches/types, abréviations, format compact des
 * tailles, calcul du code-barres EAN-13 en mode SPE et export TXT historique.
 */

export type PaireLangue = [fr: string, en: string];

/** Correspondance code couleur → libellé FR / EN (codes inconnus : code brut affiché). */
export const COULEURS: Record<string, PaireLangue> = {
  BLC: ["Blanc", "White"],
  NOIR: ["Noir", "Black"],
  NE: ["Noir", "Black"],
  GRIS: ["Gris", "Grey"],
  VERT: ["Vert", "Green"],
  ROUG: ["Rouge", "Red"],
  ORAN: ["Orange", "Orange"],
  JA: ["Jaune", "Yellow"],
  JAUN: ["Jaune", "Yellow"],
  BE: ["Beige", "Beige"],
  BEIG: ["Beige", "Beige"],
  BR: ["Brun", "Brown"],
  BRU: ["Brun", "Brown"],
  MARR: ["Marron", "Brown"],
  MARI: ["Marine", "Navy"],
  ROI: ["Bleu Roi", "Royal Blue"],
  DEN: ["Denim", "Denim"],
  KAK: ["Kaki", "Khaki"],
  KHAK: ["Kaki", "Khaki"],
  TAUP: ["Taupe", "Taupe"],
  MOKA: ["Moka", "Mocha"],
  CHOC: ["Chocolat", "Chocolate"],
  CARA: ["Caramel", "Caramel"],
  FUSH: ["Fuchsia", "Fuchsia"],
  BORD: ["Bordeaux", "Burgundy"],
  PIST: ["Pistache", "Pistachio"],
  PARM: ["Parme", "Lavender"],
  ANTH: ["Anthracite", "Charcoal"],
  ACIE: ["Acier", "Steel Grey"],
  KIRS: ["Kirsch", "Cherry"],
  FICE: ["Ficelle", "String"],
  SOUR: ["Gris souris", "Mouse Grey"],
  PO: ["Poudré", "Powder Pink"],
  OPER: ["Opéra", "Opera"],
  AR: ["Argent", "Silver"],
  AN: ["Anis", "Anise"],
  ES: ["Écru", "Ecru"],
  PDP2: ["Peau de pêche", "Peach"],
  UNI: ["Uni", "Plain"],
  // AF, ALL, SF, US : correspondance inconnue, code brut affiché
};

/** Types de manche → libellés FR / EN. */
export const MANCHES: Record<string, PaireLangue> = {
  "Longues / Long": ["Manches longues", "Long sleeves"],
  "Courtes / Short": ["Manches courtes", "Short sleeves"],
  "3/4 / 3/4": ["Manches 3/4", "3/4 sleeves"],
};

/** Types de produit (valeur « FR|EN » utilisée par le sélecteur). */
export const TYPES: Array<{ value: string; label: string }> = [
  { value: "Veste|Jacket", label: "Veste" },
  { value: "Tablier|Apron", label: "Tablier" },
  { value: "Pantalon|Pants", label: "Pantalon" },
  { value: "Toque|Chef hat", label: "Toque" },
];

/** Enregistrement catalogue : [article, couleur (code), taille, manche, code-barre]. */
export type RecordRef = [string, string, string, string, string];

export function couleurLabel(c: string): PaireLangue {
  return COULEURS[c] ?? [c, c];
}

/**
 * Limite de lisibilité de la ligne couleur sur l'étiquette (55 × 35 mm) :
 * au-delà, on n'affiche que le français pour garder l'étiquette lisible.
 */
export const LIMITE_COULEUR_BILINGUE = 20;

/**
 * Affichage étiquette d'une couleur : « Anglais / Français » (ex. « White / Blanc »),
 * sauf si l'ensemble dépasse la zone imprimable → français seul (ex. « Blanc cassé »).
 * Priorité absolue : lisibilité > bilinguisme.
 */
export function couleurAffichee(code: string): string {
  const [fr, en] = couleurLabel(code);
  if (!en || en === fr) return fr;
  const bilingue = `${en} / ${fr}`;
  return bilingue.length <= LIMITE_COULEUR_BILINGUE ? bilingue : fr;
}

/** Compare deux codes couleurs par leur libellé français (listes de sélection). */
export function comparerCouleurs(a: string, b: string): number {
  const fr = couleurLabel(a)[0].localeCompare(couleurLabel(b)[0], "fr", { sensitivity: "base" });
  return fr !== 0 ? fr : a.localeCompare(b, "fr");
}

export function mancheLabel(m: string): PaireLangue | null {
  if (!m) return null;
  return MANCHES[m] ?? [m, m];
}

/** Abréviation manche ajoutée au modèle : ML / MC / M3/4. */
export function sleeveAbbrev(m: string): string {
  if (m === "Longues / Long") return "ML";
  if (m === "Courtes / Short") return "MC";
  if (m === "3/4 / 3/4") return "M3/4";
  return "";
}

/**
 * Format compact de taille pour l'export : « T46 / S46 ».
 * Gère : TU, BEBE, tranches d'âge (3-4 A), tailles déjà préfixées (T46),
 * nombres nus (46) et tailles littérales (XS, M, XXL, M+, SPE…).
 */
export function tailleCourte(t: string): PaireLangue {
  const s = String(t).trim();
  if (s === "U" || s === "TU") return ["TU", "OS"];
  if (s === "BEBE") return ["TBB", "SBB"];

  // Tranches d'âge : « 3-4 A », « 5-6 A », « 10-12 »
  const age = s.match(/^(\d+\s*-\s*\d+)\s*A?$/i);
  if (age) {
    const r = age[1].replace(/\s+/g, "");
    return [`T${r}A`, `S${r}Y`];
  }

  // Déjà préfixée T + nombre (T0, T46) → FR inchangé, EN préfixé S
  const pref = s.match(/^T(\d+)$/i);
  if (pref) return [`T${pref[1]}`, `S${pref[1]}`];

  // Nombre nu (46) → T46 / S46
  if (/^\d+$/.test(s)) return [`T${s}`, `S${s}`];

  // Tailles littérales identiques dans les deux langues
  return [s, s];
}

/** Libellé lisible d'une taille pour les listes déroulantes (aperçu écran). */
export function tailleLabel(t: string): PaireLangue {
  const s = String(t).trim();
  if (s === "U" || s === "TU") return ["Taille unique", "One size"];
  if (s === "BEBE") return ["Bébé", "Baby"];
  const ageMatch = s.match(/^(\d+\s*-\s*\d+)\s*A?$/i);
  if (ageMatch) {
    const r = ageMatch[1].replace(/\s+/g, "");
    return [`Taille ${r} ans`, `Size ${r} years`];
  }
  const pref = s.match(/^T(\d+)$/i);
  if (pref) return [`Taille ${pref[1]}`, `Size ${pref[1]}`];
  return [`Taille ${s}`, `Size ${s}`];
}

/** Clé de contrôle EAN-13. */
export function ean13CheckDigit(body12: string): string {
  const d = body12.split("").map(Number);
  const sum = d.reduce((acc, digit, i) => acc + digit * (i % 2 === 0 ? 1 : 3), 0);
  return String((10 - (sum % 10)) % 10);
}

/** Code-barres EAN-13 généré en mode SPE (formule identique à l'application d'origine). */
export function speBarcode(
  article: string,
  couleur: string,
  manche: string,
  taille: string,
  of: string
): string {
  const str = [article, couleur, manche, taille, of].join("|");
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h * 31 + str.charCodeAt(i)) >>> 0;
  }
  const digits10 = String(h % 10000000000).padStart(10, "0");
  const body12 = `99${digits10}`;
  return body12 + ean13CheckDigit(body12);
}

/** Étiquette complète calculée, prête pour l'aperçu, l'export TXT et le .nlbl. */
export interface EtiquetteCalculee {
  modele: string;
  type: string;
  of: string;
  codeBarre: string;
  couleur: string;
  manche: string;
  taille: string;
}

export interface OptionsCalcul {
  /** Enregistrement catalogue sélectionné. */
  record: RecordRef;
  /** Numéro d'OF saisi. */
  of: string;
  /** Valeur du sélecteur de type : « FR|EN ». */
  typeValue: string;
  /** Mode SPE activé. */
  spe: boolean;
}

/**
 * Calcule les 7 valeurs variables d'une étiquette (même formule que l'original).
 * Tolérant : l'OF peut être vide (aperçu en cours de saisie) — la validation
 * stricte est faite au moment de la génération.
 */
export function calculerEtiquette({ record, of, typeValue, spe }: OptionsCalcul): EtiquetteCalculee | null {
  if (!record || !typeValue) return null;
  const [article, couleur, taille, manche, codebarre] = record;
  const mL = mancheLabel(manche);
  const sleeve = sleeveAbbrev(manche);
  const speSuffix = spe ? " SPE" : "";
  const cL = couleurAffichee(couleur);
  const tC = tailleCourte(taille);
  const [typeFr, typeEn] = typeValue.split("|");
  const modeleFinal = `${article}${sleeve ? ` ${sleeve}` : ""}${speSuffix}`;

  return {
    modele: modeleFinal,
    type: `${typeFr} / ${typeEn}`,
    of: of.trim(),
    codeBarre: spe ? speBarcode(article, couleur, manche, taille, of.trim()) : codebarre,
    // Étiquette : « White / Blanc » si lisible, sinon français seul
    couleur: cL,
    manche: mL ? `${mL[0]} / ${mL[1]}` : "",
    // Étiquette : français uniquement (ex. « T46 », jamais « T46-S46 »)
    taille: tC[0],
  };
}

/**
 * Export TXT historique (chargé via « Charger… » dans Zebra Designer).
 * Format strict de l'application d'origine : lignes Clé=valeur, fins CRLF.
 */
export function exportTxt(etiquette: EtiquetteCalculee): string {
  const lines = [
    `Modele=${etiquette.modele}`,
    `Type=${etiquette.type}`,
    `OF=${etiquette.of}`,
    `CodeBarre=${etiquette.codeBarre}`,
    `Couleur=${etiquette.couleur}`,
    `Manche=${etiquette.manche}`,
    `Taille=${etiquette.taille}`,
  ];
  return lines.join("\r\n");
}
