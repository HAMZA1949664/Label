/**
 * Client cloud Supabase (PostgREST) — Clément Design, Étiquettes & colisage.
 *
 * Architecture « miroir convergent » :
 *  - la base locale (SQLite/Prisma) reste le magasin de travail de chaque site
 *    (France + façonniers) : aucune régression, fonctionne hors ligne ;
 *  - chaque événement est AUSSI poussé vers un projet Supabase partagé via
 *    l'API REST (PostgREST) — aucune dépendance supplémentaire, de simples
 *    requêtes fetch authentifiées par la clé service_role (usage serveur) ;
 *  - l'idempotence est garantie par la contrainte unique (site_id, local_id)
 *    présente dans public/supabase-schema.sql : rejouer une file ne duplique
 *    jamais (upsert merge-duplicates).
 *
 * Sécurité : la clé service_role est stockée dans la base locale (table
 * CloudConfig, ligne unique) et n'est JAMAIS renvoyée au navigateur.
 * Repli possible sur les variables d'environnement SUPABASE_URL /
 * SUPABASE_SERVICE_ROLE_KEY si la configuration locale est absente.
 */

import { db } from "@/lib/db";
import { lireConfigFichier } from "./config-fichier";

/** Configuration opérationnelle de connexion (clé en clair — serveur seul). */
export interface ConfigCloud {
  url: string; // sans slash final, ex. https://abcdefgh.supabase.co
  cle: string; // clé service_role
  siteId: string; // identifiant du site producteur
  siteLabel: string; // libellé lisible du site
}

/** Ligne de configuration brute (Prisma) éventuellement complétée par l'env. */
export interface EtatCloud {
  config: ConfigCloud | null;
  /** fichier = cloud.config.json (géré par Clément) ; base = interface ; env = variables d'environnement. */
  source: "fichier" | "base" | "env" | "aucune";
  siteId: string;
  siteLabel: string;
  dernierTestOk: boolean | null;
  dernierTestAt: Date | null;
  dernierTestErreur: string | null;
  derniereSyncAt: Date | null;
}

/** Résultat d'un test de connexion. */
export type ResultatTest =
  | { ok: true; message: string }
  | { ok: false; erreur: string };

/** Tables du schéma cloud acceptées par le client. */
export const TABLES_CLOUD = [
  "label_generations",
  "print_events",
  "receptions",
  "reception_lines",
  "scan_records",
] as const;

export type TableCloud = (typeof TABLES_CLOUD)[number];

// ---------------------------------------------------------------------------
// Configuration (cache mémoire 5 s pour ne pas marteler la base locale)
// ---------------------------------------------------------------------------

let cacheEtat: { etat: EtatCloud; expire: number } | null = null;
const DUREE_CACHE_MS = 5_000;

/** Invalide le cache de configuration (après modification dans les routes). */
export function invaliderCacheCloud(): void {
  cacheEtat = null;
}

/** Lit (ou crée) la ligne singleton de configuration. */
async function lireOuCreerLigne() {
  const existante = await db.cloudConfig.findUnique({ where: { singleton: 1 } });
  if (existante) return existante;
  try {
    return await db.cloudConfig.create({ data: { singleton: 1 } });
  } catch {
    // Course concurrente : une autre requête vient de la créer.
    return await db.cloudConfig.findUnique({ where: { singleton: 1 } });
  }
}

/**
 * Résout la configuration effective, par ordre de priorité :
 *  1. cloud.config.json (fichier géré par Clément Design — prioritaire) ;
 *  2. ligne en base (configuration saisie dans l'interface) ;
 *  3. variables d'environnement.
 * Le site de travail vient de la base (ou du compte connecté, appliqué au
 * moment de l'empilement dans la file) — valeurs par défaut : France.
 */
export async function lireEtatCloud(forcer = false): Promise<EtatCloud> {
  if (!forcer && cacheEtat && cacheEtat.expire > Date.now()) return cacheEtat.etat;
  try {
    const ligne = await lireOuCreerLigne();
    const siteIdDefaut = ligne?.siteId || "france-hq";
    const siteLabelDefaut = ligne?.siteLabel || "France — Clément Design";

    // 1. Fichier cloud.config.json (prioritaire — façonniers n'y touchent pas)
    const fichier = await lireConfigFichier();
    if (fichier.present && fichier.supabaseUrl && fichier.supabaseCle) {
      const etat: EtatCloud = {
        config: {
          url: fichier.supabaseUrl,
          cle: fichier.supabaseCle,
          siteId: siteIdDefaut,
          siteLabel: siteLabelDefaut,
        },
        source: "fichier",
        siteId: siteIdDefaut,
        siteLabel: siteLabelDefaut,
        dernierTestOk: ligne?.dernierTestOk ?? null,
        dernierTestAt: ligne?.dernierTestAt ?? null,
        dernierTestErreur: ligne?.dernierTestErreur ?? null,
        derniereSyncAt: ligne?.derniereSyncAt ?? null,
      };
      cacheEtat = { etat, expire: Date.now() + DUREE_CACHE_MS };
      return etat;
    }

    // 2. Base locale, puis 3. variables d'environnement
    const urlBase = ligne?.supabaseUrl?.trim() || process.env.SUPABASE_URL?.trim() || "";
    const cleBase =
      ligne?.supabaseCle?.trim() ||
      process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
      process.env.SUPABASE_SERVICE_KEY?.trim() ||
      "";
    const config =
      urlBase && cleBase
        ? {
            url: urlBase.replace(/\/+$/, ""),
            cle: cleBase,
            siteId: siteIdDefaut,
            siteLabel: siteLabelDefaut,
          }
        : null;
    const etat: EtatCloud = {
      config,
      source: config ? (ligne?.supabaseUrl ? "base" : "env") : "aucune",
      siteId: siteIdDefaut,
      siteLabel: siteLabelDefaut,
      dernierTestOk: ligne?.dernierTestOk ?? null,
      dernierTestAt: ligne?.dernierTestAt ?? null,
      dernierTestErreur: ligne?.dernierTestErreur ?? null,
      derniereSyncAt: ligne?.derniereSyncAt ?? null,
    };
    cacheEtat = { etat, expire: Date.now() + DUREE_CACHE_MS };
    return etat;
  } catch (error) {
    console.error("Lecture de la configuration cloud impossible :", error);
    return {
      config: null,
      source: "aucune",
      siteId: "france-hq",
      siteLabel: "France — Clément Design",
      dernierTestOk: null,
      dernierTestAt: null,
      dernierTestErreur: null,
      derniereSyncAt: null,
    };
  }
}

// ---------------------------------------------------------------------------
// Validation des saisies
// ---------------------------------------------------------------------------

/** Normalise et valide une URL de projet Supabase. Retourne l'URL ou une erreur FR. */
export function validerUrlSupabase(brut: string): { url: string } | { erreur: string } {
  const url = brut.trim().replace(/\/+$/, "");
  if (!/^https:\/\/[a-z0-9.-]+(:\d{2,5})?$/i.test(url)) {
    return {
      erreur:
        "URL invalide — format attendu : https://xxxxxxxx.supabase.co (copiée dans Project Settings → API).",
    };
  }
  return { url };
}

/** Valide la clé service_role. Retourne la clé ou une erreur FR. */
export function validerCleSupabase(brut: string): { cle: string } | { erreur: string } {
  const cle = brut.trim();
  if (cle.length < 20) {
    return {
      erreur:
        "Clé trop courte — copiez la clé API complète (Project Settings → API : « sb_publishable_… » ou « service_role »).",
    };
  }
  return { cle };
}

/** Valide l'identifiant de site (a-z, 0-9, tirets). */
export function validerSiteId(brut: string): { id: string } | { erreur: string } {
  const id = brut.trim();
  if (!/^[a-z0-9-]{1,40}$/.test(id)) {
    return {
      erreur:
        "Identifiant de site invalide (lettres minuscules, chiffres et tirets, 40 caractères max).",
    };
  }
  return { id };
}

/** Aperçu masqué d'une clé (affichage UI). */
export function apercuCle(cle: string): string {
  if (!cle) return "";
  return `••••${cle.slice(-4)}`;
}

// ---------------------------------------------------------------------------
// Client PostgREST
// ---------------------------------------------------------------------------

function enTetesRest(cle: string): Record<string, string> {
  return {
    apikey: cle,
    Authorization: `Bearer ${cle}`,
    "Content-Type": "application/json",
  };
}

/** Extrait un message FR d'une réponse PostgREST en échec. */
async function erreurRest(res: Response, contexte: string): Promise<string> {
  let detail = "";
  try {
    const corps = (await res.json()) as { message?: string; hint?: string };
    if (corps?.message) detail = ` — ${corps.message}`;
  } catch {
    // réponse non JSON (proxy, HTML…) : on reste sur le statut
  }
  return `${contexte} (HTTP ${res.status}${detail})`;
}

/**
 * Teste la connexion : la table label_generations doit répondre à un SELECT
 * minimal. Les erreurs sont traduites en messages actionnables en français.
 */
export async function testerConnexionCloud(url: string, cle: string): Promise<ResultatTest> {
  try {
    const res = await fetch(`${url}/rest/v1/label_generations?select=id&limit=1`, {
      headers: enTetesRest(cle),
      signal: AbortSignal.timeout(10_000),
    });
    if (res.ok) {
      return {
        ok: true,
        message:
          "Connexion réussie : la base répond et le schéma est présent (table label_generations accessible).",
      };
    }
    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        erreur:
          "Clé refusée par Supabase (HTTP 401/403). Vérifiez que vous avez copié la clé API complète (sb_publishable_… ou service_role).",
      };
    }
    if (res.status === 404) {
      return {
        ok: false,
        erreur:
          "Table « label_generations » introuvable : exécutez d'abord le script SQL (onglet Guide → Copier le script SQL → SQL Editor → Run).",
      };
    }
    return { ok: false, erreur: await erreurRest(res, "Supabase a refusé la requête") };
  } catch (error) {
    const cause = error instanceof Error ? error.message : String(error);
    return {
      ok: false,
      erreur: `URL injoignable (${cause}). Vérifiez l'adresse du projet et l'accès Internet.`,
    };
  }
}

/**
 * Upsert d'un lot de lignes (idempotent : conflit sur (site_id, local_id)).
 * Lève une exception en cas d'échec réseau/HTTP — la file d'attente décide
 * alors du sort des lignes (rejouées plus tard, jamais perdues).
 */
export async function upsertCloud(
  table: TableCloud,
  lignes: Record<string, unknown>[],
  config: ConfigCloud
): Promise<void> {
  for (let i = 0; i < lignes.length; i += 100) {
    const lot = lignes.slice(i, i + 100);
    const res = await fetch(
      `${config.url}/rest/v1/${table}?on_conflict=site_id,local_id`,
      {
        method: "POST",
        headers: {
          ...enTetesRest(config.cle),
          Prefer: "resolution=merge-duplicates,return=minimal",
        },
        body: JSON.stringify(lot),
        signal: AbortSignal.timeout(15_000),
      }
    );
    if (!res.ok) {
      throw new Error(await erreurRest(res, `Écriture cloud « ${table} » refusée`));
    }
  }
}

/** Paramètres d'une sélection cloud. */
export interface ParamsSelection {
  colonnes: string;
  filtres?: string[]; // ex. ["site_id=eq.tn-fac1", "genere_at=gte.2026-01-01T00:00:00Z"]
  ordre?: string; // ex. "genere_at.desc"
  limite: number;
}

/** SELECT PostgREST (lecture du journal multi-sites). */
export async function selectionnerCloud(
  table: TableCloud,
  params: ParamsSelection,
  config: ConfigCloud
): Promise<Record<string, unknown>[]> {
  const q = new URLSearchParams({ select: params.colonnes, limit: String(params.limite) });
  if (params.ordre) q.set("order", params.ordre);
  const suffixe = (params.filtres ?? [])
    .map((f) => {
      const idx = f.indexOf("=");
      return `&${f.slice(0, idx)}=${f.slice(idx + 1)}`;
    })
    .join("");
  const res = await fetch(`${config.url}/rest/v1/${table}?${q.toString()}${suffixe}`, {
    headers: enTetesRest(config.cle),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    throw new Error(await erreurRest(res, `Lecture cloud « ${table} » impossible`));
  }
  return (await res.json()) as Record<string, unknown>[];
}
