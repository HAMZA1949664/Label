/**
 * Réceptions prévues — moteur serveur (résolution des codes scannés et
 * calcul de l'état attendu / reçu). Résolution identique au colisage :
 * 1. catalogue FAB (code-barres EAN-13 du stock),
 * 2. mémoire des étiquettes générées (LabelRecord — SPE notamment),
 * 3. recalcul SPE depuis les OF candidats (repli historique),
 * 4. inconnu.
 *
 * Attribution aux lignes attendues :
 * - correspondance exacte (OF + modèle + couleur + taille + manche) ;
 * - sinon, répartition « déficit maximal d'abord » sur les lignes de même
 *   SKU (un code FAB scanné ne porte pas son OF : il remplit la ligne la
 *   plus en manque — comme au déchargement réel d'un camion) ;
 * - aucun correspondant → « hors prévue » ; code illisible → « inconnu ».
 */

import { db } from "@/lib/db";
import {
  chargerCatalogue,
  construireIndexSpeGlobal,
  modeleComplet,
} from "@/lib/label-records";
import { couleurLabel, mancheLabel, tailleCourte } from "@/lib/label-data";
import type {
  EtatReception,
  HorsPrevueItem,
  InconnuItem,
  LigneEtatReception,
  ResumeReception,
} from "@/lib/receptions";

/** Résolution d'un code scanné vers sa ligne physique (sans OF fiable). */
interface CodeResolu {
  of: string;
  modele: string;
  couleur: string;
  couleurCode: string;
  taille: string;
  manche: string;
}

/** Résout tous les codes (dédupliqués) en une seule passe catalogue/base. */
async function resoudreCodes(
  codes: string[]
): Promise<{ resoluParCode: Map<string, CodeResolu>; inconnusParCode: Map<string, true> }> {
  const resoluParCode = new Map<string, CodeResolu>();
  const inconnusParCode = new Map<string, true>();
  if (codes.length === 0) return { resoluParCode, inconnusParCode };

  const { lignes, fabParCode } = await chargerCatalogue();

  // 1 + 2. FAB d'abord, puis mémoire des étiquettes générées (par paquets).
  const restants: string[] = [];
  for (const c of codes) {
    const fab = fabParCode.get(c);
    if (fab) {
      resoluParCode.set(c, {
        of: "",
        modele: modeleComplet(fab.article, fab.manche, false),
        couleur: couleurLabel(fab.couleur)[0],
        couleurCode: fab.couleur,
        taille: tailleCourte(fab.taille)[0],
        manche: mancheLabel(fab.manche)?.[0] ?? "",
      });
    } else {
      restants.push(c);
    }
  }

  const encoreRestants: string[] = [];
  for (let i = 0; i < restants.length; i += 500) {
    const morceau = restants.slice(i, i + 500);
    const enregistrements = await db.labelRecord.findMany({
      where: { codeBarre: { in: morceau } },
      select: {
        codeBarre: true,
        of: true,
        modele: true,
        couleur: true,
        couleurCode: true,
        taille: true,
        manche: true,
      },
    });
    const vus = new Set<string>();
    for (const r of enregistrements) {
      if (!vus.has(r.codeBarre)) {
        vus.add(r.codeBarre);
        resoluParCode.set(r.codeBarre, {
          of: r.of,
          modele: r.modele,
          couleur: r.couleur,
          couleurCode: r.couleurCode,
          taille: r.taille,
          manche: r.manche,
        });
      }
    }
    for (const c of morceau) {
      if (!vus.has(c)) encoreRestants.push(c);
    }
  }

  // 3. Repli : recalcul SPE depuis les OF candidats (journal + saisie vide).
  if (encoreRestants.length > 0) {
    const speIndex = await construireIndexSpeGlobal(lignes, []);
    for (const c of encoreRestants) {
      const spe = speIndex.get(c);
      if (spe) {
        resoluParCode.set(c, {
          of: spe.of,
          modele: modeleComplet(spe.ref.article, spe.ref.manche, true),
          couleur: couleurLabel(spe.ref.couleur)[0],
          couleurCode: spe.ref.couleur,
          taille: tailleCourte(spe.ref.taille)[0],
          manche: mancheLabel(spe.ref.manche)?.[0] ?? "",
        });
      } else {
        inconnusParCode.set(c, true);
      }
    }
  }

  return { resoluParCode, inconnusParCode };
}

/** Construit l'état complet d'une réception (lignes + pointages cumulés). */
export async function construireEtatReception(
  receptionId: string
): Promise<EtatReception | null> {
  const reception = await db.reception.findUnique({
    where: { id: receptionId },
    include: { lignes: { orderBy: [{ of: "asc" }, { modele: "asc" }] } },
  });
  if (!reception) return null;

  const scans = await db.scanRecord.findMany({
    where: { receptionId },
    select: { codeBarre: true, quantite: true },
  });

  const codesUniques = [...new Set(scans.map((s) => s.codeBarre))];
  const { resoluParCode, inconnusParCode } = await resoudreCodes(codesUniques);

  // Quantités pointées par code (occurrences cumulées des sessions).
  const pointeParCode = new Map<string, number>();
  let pointeTotal = 0;
  for (const s of scans) {
    pointeParCode.set(s.codeBarre, (pointeParCode.get(s.codeBarre) ?? 0) + s.quantite);
    pointeTotal += s.quantite;
  }

  // Index des lignes attendues.
  const cleExacte = (l: {
    of: string;
    modele: string;
    couleur: string;
    taille: string;
    manche: string;
  }) => `${l.of}|${l.modele}|${l.couleur}|${l.taille}|${l.manche}`;
  const parSku = new Map<string, number[]>();
  reception.lignes.forEach((l, idx) => {
    const k = `${l.modele}|${l.couleur}|${l.taille}|${l.manche}`;
    const arr = parSku.get(k);
    if (arr) arr.push(idx);
    else parSku.set(k, [idx]);
  });

  const recu = new Array<number>(reception.lignes.length).fill(0);
  const horsPrevueMap = new Map<string, HorsPrevueItem>();
  const inconnusMap = new Map<string, InconnuItem>();

  const attribuer = (code: string, resolu: CodeResolu, quantite: number) => {
    // 1. Correspondance exacte (SPE : l'OF est porté par le code).
    const idxExact = reception.lignes.findIndex(
      (l) =>
        cleExacte(l) ===
        `${resolu.of}|${resolu.modele}|${resolu.couleur}|${resolu.taille}|${resolu.manche}`
    );
    if (idxExact >= 0) {
      recu[idxExact] += quantite;
      return;
    }
    // 2. Même SKU (le code FAB ne porte pas d'OF) : répartition déficit
    //    maximal d'abord, OF croissant en cas d'égalité — déterministe.
    const candidats = (parSku.get(
      `${resolu.modele}|${resolu.couleur}|${resolu.taille}|${resolu.manche}`
    ) ?? [])
      .slice()
      .sort((a, b) => {
        const deficitA = reception.lignes[a].attendu - recu[a];
        const deficitB = reception.lignes[b].attendu - recu[b];
        if (deficitA !== deficitB) return deficitB - deficitA;
        return (reception.lignes[a].of || "").localeCompare(
          reception.lignes[b].of || "",
          "fr",
          { numeric: true }
        );
      });
    if (candidats.length > 0) {
      let reste = quantite;
      // Remplit d'abord les déficits (recu < attendu), puis la 1re ligne.
      for (const idx of candidats) {
        if (reste <= 0) break;
        const deficit = reception.lignes[idx].attendu - recu[idx];
        if (deficit > 0) {
          const verse = Math.min(deficit, reste);
          recu[idx] += verse;
          reste -= verse;
        }
      }
      if (reste > 0) recu[candidats[0]] += reste;
      return;
    }
    // 3. Reconnaissable mais non prévu dans cette réception.
    const precedent = horsPrevueMap.get(code);
    if (precedent) precedent.quantite += quantite;
    else
      horsPrevueMap.set(code, {
        code,
        quantite,
        modele: resolu.modele,
      });
  };

  for (const [code, quantite] of pointeParCode) {
    const resolu = resoluParCode.get(code);
    if (resolu) attribuer(code, resolu, quantite);
    else if (inconnusParCode.has(code))
      inconnusMap.set(code, { code, quantite });
  }

  const lignesEtat: LigneEtatReception[] = reception.lignes.map((l, i) => {
    const ecart = recu[i] - l.attendu;
    const statut: LigneEtatReception["statut"] =
      recu[i] > l.attendu
        ? "excedent"
        : recu[i] === l.attendu && l.attendu > 0
          ? "complet"
          : recu[i] === 0
            ? "zero"
            : "partiel";
    return {
      id: l.id,
      of: l.of,
      modele: l.modele,
      couleur: l.couleur,
      couleurCode: l.couleurCode,
      taille: l.taille,
      manche: l.manche,
      attendu: l.attendu,
      recu: recu[i],
      ecart,
      statut,
    };
  });

  const attenduTotal = lignesEtat.reduce((s, l) => s + l.attendu, 0);
  const recuTotal = lignesEtat.reduce((s, l) => s + l.recu, 0);

  return {
    reception: {
      id: reception.id,
      titre: reception.titre,
      statut: reception.statut,
      note: reception.note,
      createdAt: reception.createdAt.toISOString(),
      clotureAt: reception.clotureAt ? reception.clotureAt.toISOString() : null,
    },
    lignes: lignesEtat,
    horsPrevue: [...horsPrevueMap.values()].sort(
      (a, b) => b.quantite - a.quantite || a.code.localeCompare(b.code)
    ),
    inconnus: [...inconnusMap.values()].sort(
      (a, b) => b.quantite - a.quantite || a.code.localeCompare(b.code)
    ),
    resume: {
      attenduTotal,
      recuTotal,
      pointeTotal,
      lignesTotal: lignesEtat.length,
      lignesCompletes: lignesEtat.filter((l) => l.statut === "complet").length,
      lignesPartielles: lignesEtat.filter((l) => l.statut === "partiel").length,
      lignesZero: lignesEtat.filter((l) => l.statut === "zero").length,
      tauxPct:
        attenduTotal > 0 ? Math.round((recuTotal / attenduTotal) * 100) : 0,
      horsPrevueQuantite: [...horsPrevueMap.values()].reduce(
        (s, h) => s + h.quantite,
        0
      ),
      inconnusQuantite: [...inconnusMap.values()].reduce(
        (s, i) => s + i.quantite,
        0
      ),
    },
  };
}

/** Résumés de toutes les réceptions (pour la liste déroulante). */
export async function resumerReceptions(): Promise<ResumeReception[]> {
  const receptions = await db.reception.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      lignes: {
        select: {
          attendu: true,
          modele: true,
          couleur: true,
          taille: true,
          manche: true,
        },
      },
      scans: { select: { codeBarre: true, quantite: true } },
    },
  });

  if (receptions.length === 0) return [];

  // Résolution unique de tous les codes pointés (toutes réceptions confondues).
  const tousCodes = [
    ...new Set(receptions.flatMap((r) => r.scans.map((s) => s.codeBarre))),
  ];
  const { resoluParCode, inconnusParCode } = await resoudreCodes(tousCodes);

  return receptions.map((r) => {
    const attenduTotal = r.lignes.reduce((s, l) => s + l.attendu, 0);
    // Recu attribuable = codes résolus dont le SKU existe dans la réception.
    const skus = new Set(
      r.lignes.map(
        (l) => `${l.modele}|${l.couleur}|${l.taille}|${l.manche}`
      )
    );
    let recuTotal = 0;
    for (const s of r.scans) {
      const resolu = resoluParCode.get(s.codeBarre);
      if (!resolu) continue; // inconnu ou hors prévue → non compté ici
      if (
        skus.has(
          `${resolu.modele}|${resolu.couleur}|${resolu.taille}|${resolu.manche}`
        )
      ) {
        recuTotal += s.quantite;
      }
    }
    void inconnusParCode;
    return {
      id: r.id,
      titre: r.titre,
      statut: r.statut,
      createdAt: r.createdAt.toISOString(),
      lignesTotal: r.lignes.length,
      attenduTotal,
      recuTotal,
      tauxPct:
        attenduTotal > 0 ? Math.round((recuTotal / attenduTotal) * 100) : 0,
    };
  });
}
