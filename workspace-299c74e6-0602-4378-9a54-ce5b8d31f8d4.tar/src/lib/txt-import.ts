/**
 * Analyse d'un fichier .TXT historique (format « Clé=valeur », fins CRLF)
 * exporté par l'application d'origine ou par ce générateur — pour le
 * réimporter dans la file d'impression sans repasser par le catalogue.
 *
 * Format attendu (une étiquette par bloc de 7 lignes, plusieurs blocs
 * consécutifs acceptés — fichiers concaténés) :
 *   Modele=SFAX MC
 *   Type=Veste / Jacket
 *   OF=078594
 *   CodeBarre=3700791711624
 *   Couleur=Noir
 *   Manche=Manches courtes / Short sleeves
 *   Taille=T3-S3
 *
 * Les valeurs sont reprises telles quelles : ce sont exactement les 7
 * variables intégrées au .NLBL (aucune recalculée). Un bloc n'est conservé
 * que si tous les champs obligatoires sont présents et si le code-barres
 * est un EAN-13 valide (13 chiffres + clé de contrôle).
 */

import { ean13Valide } from "@/lib/nlbl/validation";
import type { EtiquetteCalculee } from "@/lib/label-data";

/** Résultat d'analyse d'un fichier .TXT importé. */
export interface ResultatTxtImport {
  /** Étiquettes valides, prêtes à être ajoutées à la file. */
  etiquettes: EtiquetteCalculee[];
  /** Blocs ignorés (champ obligatoire absent ou code-barres invalide). */
  ignorees: number;
  /** Nombre total de blocs trouvés dans le fichier. */
  total: number;
}

/** Taille maximale acceptée pour un fichier .TXT importé (1 Mo). */
export const TAILLE_MAX_TXT = 1_000_000;

/** Nombre maximal d'étiquettes conservées en une importation. */
export const MAX_IMPORT_TXT = 100;

/** Clé de la première ligne d'un bloc (déclencheur d'un nouveau bloc). */
const CLE_MODELE = "modele";

/** Les 7 clés attendues, en minuscules, sans accents. */
const CLES = [
  "modele",
  "type",
  "of",
  "codebarre",
  "couleur",
  "manche",
  "taille",
] as const;

type Cles = (typeof CLES)[number];

/**
 * Analyse le contenu texte d'un .TXT et retourne les étiquettes réutilisables.
 * Tolérant : ordre des lignes libre, espaces autour des « = », clés insensibles
 * à la casse, lignes vides ignorées, fins LF ou CRLF acceptées.
 */
export function analyserTxtImport(texte: string): ResultatTxtImport {
  const etiquettes: EtiquetteCalculee[] = [];
  let ignorees = 0;
  let total = 0;

  const lignes = texte.replace(/\r\n/g, "\n").split("\n");
  let bloc: Partial<Record<Cles, string>> = {};

  const cloreBloc = () => {
    if (Object.keys(bloc).length === 0) return;
    total += 1;
    const modele = (bloc.modele ?? "").trim();
    const type = (bloc.type ?? "").trim();
    const of = (bloc.of ?? "").trim();
    const codeBarre = (bloc.codebarre ?? "").trim();
    const couleur = (bloc.couleur ?? "").trim();
    const manche = (bloc.manche ?? "").trim();
    const taille = (bloc.taille ?? "").trim();

    const valide =
      modele.length > 0 &&
      type.length > 0 &&
      of.length > 0 &&
      couleur.length > 0 &&
      taille.length > 0 &&
      ean13Valide(codeBarre);

    if (valide && etiquettes.length < MAX_IMPORT_TXT) {
      etiquettes.push({ modele, type, of, codeBarre, couleur, manche, taille });
    } else {
      ignorees += 1;
    }
    bloc = {};
  };

  for (const ligneBrute of lignes) {
    const ligne = ligneBrute.trim();
    if (ligne.length === 0) continue;
    const egal = ligne.indexOf("=");
    if (egal <= 0) continue;
    const cle = ligne.slice(0, egal).trim().toLowerCase();
    const valeur = ligne.slice(egal + 1).trim();

    if (cle === CLE_MODELE) {
      cloreBloc(); // un nouveau « Modele= » démarre le bloc suivant
      bloc[CLE_MODELE] = valeur;
      continue;
    }
    if ((CLES as readonly string[]).includes(cle)) {
      if (bloc[cle as Cles] === undefined) bloc[cle as Cles] = valeur;
    }
  }
  cloreBloc();

  return { etiquettes, ignorees, total };
}
