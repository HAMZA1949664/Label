/**
 * File d'attente de synchronisation cloud — Clément Design, Étiquettes & colisage.
 *
 * Principe (résilience ateliers) :
 *  1. `empilerSync(table, lignes)` est appelé par chaque événement métier
 *     (étiquette générée, lot imprimé, réception, pointage de scans). Il
 *     écrit D'ABORD dans la file locale (SQLite) — opération rapide, locale,
 *     fiable : rien n'est perdu même sans Internet.
 *  2. `viderFichierCloud()` vide ensuite la file vers Supabase en upserts
 *     idempotents (site_id + local_id) : re-jouer ne duplique jamais.
 *     En cas d'échec réseau, les lignes RESTENT en file (statut inchangé) et
 *     la reprise est automatique (déclenchement différé, statut de la
 *     connexion, ou bouton « Synchroniser maintenant »).
 *
 * Les fonctions ne lèvent JAMAIS d'exception : la synchronisation est
 * « best effort » et ne doit jamais interrompre le flux métier (génération,
 * colisage, impression).
 */

import { db } from "@/lib/db";
import {
  TABLES_CLOUD,
  lireEtatCloud,
  upsertCloud,
  type TableCloud,
} from "./supabase";
import { lireCompteRequete } from "./session";

/** Taille des lots lus dans la file à chaque passage. */
const TAILLE_LOT = 500;
/** Garde-fou : au-delà de ce volume en attente, on purge les plus anciens. */
const MAX_EN_ATTENTE = 8_000;
/** Interval minimal entre deux vidages automatiques (anti-martelage). */
const DEBOUNCE_AUTO_MS = 15_000;
/** Purge des lignes déjà synchronisées après ce délai. */
const RETENTION_SYNC_MS = 3 * 24 * 60 * 60 * 1_000;

/** Limite de sécurité : longueur d'un payload JSON individuel. */
const TAILLE_MAX_PAYLOAD = 120_000;

let vidageEnCours = false;
let dernierAutoMs = 0;

export interface ResultatSync {
  /** Lignes effectivement poussées vers Supabase. */
  poussees: number;
  /** Lignes restant en file après le passage. */
  restantes: number;
  /** Message d'erreur FR si le vidage a échoué (sinon null). */
  erreur: string | null;
  /** Vrai si aucune configuration Supabase n'est disponible. */
  nonConfigure: boolean;
}

/** Compte les lignes en attente dans la file locale. */
export async function compterEnAttente(): Promise<number> {
  try {
    return await db.cloudSyncQueue.count({ where: { statut: "en_attente" } });
  } catch {
    return 0;
  }
}

/** Ensemble des tables autorisées (garde-fou). */
const tablesAutorisees = new Set<string>(TABLES_CLOUD);

/**
 * Site à graver sur les événements : le compte connecté (Archipel, Nastex,
 * Clément…) est prioritaire — c'est lui qui trace « qui a produit quoi » dans
 * la base partagée. Repli : site configuré dans l'interface (requêtes hors
 * session, auth désactivée).
 */
async function siteEffectif(): Promise<{ siteId: string; siteLabel: string }> {
  const etat = await lireEtatCloud();
  const compte = await lireCompteRequete();
  if (compte) return { siteId: compte.siteId, siteLabel: compte.siteLabel };
  return { siteId: etat.siteId, siteLabel: etat.siteLabel };
}

/**
 * Empile des lignes à pousser vers Supabase (jamais bloquant, jamais
 * d'exception). Les champs site_id / site_label sont injectés
 * automatiquement depuis le compte connecté (ou le site configuré).
 */
export async function empilerSync(
  table: TableCloud,
  lignes: Record<string, unknown>[]
): Promise<void> {
  if (!tablesAutorisees.has(table) || lignes.length === 0) return;
  try {
    const site = await siteEffectif();
    const donnees = lignes.map((l) =>
      JSON.stringify({
        site_id: site.siteId,
        site_label: site.siteLabel,
        ...l,
      }).slice(0, TAILLE_MAX_PAYLOAD)
    );
    await db.cloudSyncQueue.createMany({
      data: donnees.map((payload) => ({ table, payload })),
    });

    // Garde-fou de volume : purge les plus anciennes au-delà du plafond.
    const enAttente = await db.cloudSyncQueue.count({ where: { statut: "en_attente" } });
    if (enAttente > MAX_EN_ATTENTE) {
      const excedent = enAttente - MAX_EN_ATTENTE;
      const anciennes = await db.cloudSyncQueue.findMany({
        where: { statut: "en_attente" },
        orderBy: { id: "asc" },
        take: excedent,
        select: { id: true },
      });
      if (anciennes.length > 0) {
        await db.cloudSyncQueue.deleteMany({
          where: { id: { in:anciennes.map((a) => a.id) } },
        });
        console.warn(
          `File cloud saturée (${enAttente}) : ${anciennes.length} événements les plus anciens purgés.`
        );
      }
    }

    // Reprise différée : tente de vider la file (anti-martelage intégré).
    declencherSyncAuto();
  } catch (error) {
    // La file ne doit jamais casser le flux métier.
    console.error("Empilement de la synchronisation cloud impossible :", error);
  }
}

/** Déclenche un vidage automatique si le délai minimal est écoulé. */
export function declencherSyncAuto(): void {
  const maintenant = Date.now();
  if (vidageEnCours || maintenant - dernierAutoMs < DEBOUNCE_AUTO_MS) return;
  dernierAutoMs = maintenant;
  void viderFichierCloud().catch(() => {});
}

/**
 * Vide la file d'attente vers Supabase (jusqu'à 5 lots de 500 lignes par
 * passage). Les lignes en échec réseau restent en file avec le message
 * d'erreur — elles seront rejouées au prochain passage.
 */
export async function viderFichierCloud(): Promise<ResultatSync> {
  const restantesAvant = await compterEnAttente();
  const etat = await lireEtatCloud();
  if (!etat.config) {
    return {
      poussees: 0,
      restantes: restantesAvant,
      erreur: null,
      nonConfigure: true,
    };
  }
  if (vidageEnCours) {
    return { poussees: 0, restantes: restantesAvant, erreur: null, nonConfigure: false };
  }
  vidageEnCours = true;
  let poussees = 0;
  let erreur: string | null = null;
  try {
    passe: for (let passage = 0; passage < 5; passage += 1) {
      const lot = await db.cloudSyncQueue.findMany({
        where: { statut: "en_attente" },
        orderBy: { id: "asc" },
        take: TAILLE_LOT,
      });
      if (lot.length === 0) break;

      // Regroupe par table cible (un appel réseau par table).
      const parTable = new Map<string, Array<{ id: number; ligne: Record<string, unknown> }>>();
      for (const item of lot) {
        try {
          const ligne = JSON.parse(item.payload) as Record<string, unknown>;
          const groupe = parTable.get(item.table) ?? [];
          groupe.push({ id: item.id, ligne });
          parTable.set(item.table, groupe);
        } catch {
          // Payload corrompu (jamais censé arriver) : on écarte la ligne.
          await db.cloudSyncQueue
            .update({
              where: { id: item.id },
              data: { statut: "erreur", erreur: "Payload illisible (écarté)." },
            })
            .catch(() => {});
        }
      }

      for (const [table, groupe] of parTable) {
        try {
          await upsertCloud(table as TableCloud, groupe.map((g) => g.ligne), etat.config!);
          await db.cloudSyncQueue.updateMany({
            where: { id: { in: groupe.map((g) => g.id) } },
            data: { statut: "synchronise", syncAt: new Date(), erreur: null },
          });
          poussees += groupe.length;
        } catch (e) {
          // Échec réseau/HTTP : les lignes RESTENT en attente (rejeu auto),
          // on note l'erreur pour l'affichage puis on arrête (fail fast).
          erreur = e instanceof Error ? e.message : String(e);
          await db.cloudSyncQueue
            .updateMany({
              where: { id: { in: groupe.map((g) => g.id) } },
              data: { erreur: erreur.slice(0, 500) },
            })
            .catch(() => {});
          break passe;
        }
      }
    }

    if (poussees > 0) {
      const borne = new Date(Date.now() - RETENTION_SYNC_MS);
      await db.cloudSyncQueue
        .deleteMany({ where: { statut: "synchronise", syncAt: { lt: borne } } })
        .catch(() => {});
      await db.cloudConfig
        .updateMany({ data: { derniereSyncAt: new Date() } })
        .catch(() => {});
    }
    return { poussees, restantes: await compterEnAttente(), erreur, nonConfigure: false };
  } catch (error) {
    return {
      poussees,
      restantes: await compterEnAttente(),
      erreur: error instanceof Error ? error.message : String(error),
      nonConfigure: false,
    };
  } finally {
    vidageEnCours = false;
  }
}
