/**
 * Sessions des comptes — Clément Design, Étiquettes & colisage.
 *
 * Principe : les comptes vivent dans cloud.config.json (gérés par Clément,
 * côté serveur). Après connexion, un cookie httpOnly signé (HMAC-SHA256)
 * identifie l'utilisateur pendant 30 jours. Aucun mot de passe ni secret ne
 * quitte le serveur : le navigateur ne reçoit que le nom et le rôle.
 *
 * Rôles :
 *  - 'faconnier' : génération et impression d'étiquettes + synchronisation
 *    cloud (le colisage / la réception est réservé au compte France) ;
 *  - 'france'    : accès complet (génération, réception, colisage).
 *
 * Si aucun compte n'est défini dans le fichier (ou fichier absent), tout ce
 * module devient transparent : comportement historique préservé.
 */

import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "node:crypto";
import { lireConfigFichier, type RoleCompte } from "./config-fichier";

export const NOM_COOKIE = "cld_compte";
const DUREE_SESSION_MS = 30 * 24 * 60 * 60 * 1_000; // 30 jours

/** Vue publique d'un compte (sans code — envoyée au navigateur). */
export interface ComptePublic {
  identifiant: string;
  nom: string;
  role: RoleCompte;
  siteId: string;
  siteLabel: string;
}

interface ChargeSession extends ComptePublic {
  exp: number; // expiration (epoch ms)
}

// ---------------------------------------------------------------------------
// Signature HMAC (cookie infalsifiable)
// ---------------------------------------------------------------------------

function cleSecrete(): Promise<string> {
  return lireConfigFichier().then(
    (cfg) =>
      `cld|${cfg.secretSession || "(defaut)"}|${
        cfg.supabaseCle || "sans-cle"
      }|clément-design-étiquettes-colisage`
  );
}

function signe(payload: string, secret: string): string {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

function encoder(session: ChargeSession, secret: string): string {
  const payload = Buffer.from(JSON.stringify(session), "utf8").toString("base64url");
  return `${payload}.${signe(payload, secret)}`;
}

function decoder(token: string, secret: string): ChargeSession | null {
  const idx = token.lastIndexOf(".");
  if (idx <= 0) return null;
  const payload = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const a = Buffer.from(sig);
  const b = Buffer.from(signe(payload, secret));
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const s = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as ChargeSession;
    if (!s?.identifiant || typeof s.exp !== "number" || s.exp < Date.now()) return null;
    return s;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Connexion / vérification
// ---------------------------------------------------------------------------

/** Vérifie identifiant + code contre cloud.config.json (comparaison sûre). */
export async function verifierIdentifiants(
  identifiant: string,
  code: string
): Promise<ComptePublic | null> {
  const cfg = await lireConfigFichier();
  const cible = cfg.comptes.find((c) => c.identifiant === identifiant.trim().toLowerCase());
  if (!cible) return null;
  const a = Buffer.from(code);
  const b = Buffer.from(cible.code);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return {
    identifiant: cible.identifiant,
    nom: cible.nom,
    role: cible.role,
    siteId: cible.siteId,
    siteLabel: cible.siteLabel,
  };
}

/** Construit le cookie de session (httpOnly, signé, 30 jours). */
export async function cookieConnexion(
  compte: ComptePublic,
  requeteHttps = false
): Promise<{
  nom: string;
  valeur: string;
  options: {
    httpOnly: true;
    sameSite: "lax";
    path: "/";
    maxAge: number;
    secure: boolean;
  };
}> {
  const token = encoder(
    { ...compte, exp: Date.now() + DUREE_SESSION_MS },
    await cleSecrete()
  );
  return {
    nom: NOM_COOKIE,
    valeur: token,
    options: {
      httpOnly: true as const,
      sameSite: "lax" as const,
      path: "/",
      maxAge: Math.floor(DUREE_SESSION_MS / 1000),
      // « secure » est activé automatiquement derrière un HTTPS (déploiement) ;
      // il reste désactivé en local/http pour ne pas casser la prévisualisation.
      secure: requeteHttps,
    },
  };
}

// ---------------------------------------------------------------------------
// Lecture du compte courant (requête en cours)
// ---------------------------------------------------------------------------

/**
 * Compte connecté pour la requête en cours. Retourne null si :
 *  - aucun compte n'est configuré (auth désactivée → comportement historique) ;
 *  - pas de cookie ou cookie invalide/expiré ;
 *  - appel hors contexte requête (script, cron) — la file cloud retombe alors
 *    sur le site configuré dans l'interface.
 */
export async function lireCompteRequete(): Promise<ComptePublic | null> {
  try {
    const cfg = await lireConfigFichier();
    if (cfg.comptes.length === 0) return null;
    const jar = await cookies();
    const token = jar.get(NOM_COOKIE)?.value;
    if (!token) return null;
    const s = decoder(token, await cleSecrete());
    if (!s) return null;
    // Le compte doit toujours exister dans le fichier (codes / rôles à jour) :
    // retirer un compte du fichier déconnecte immédiatement son cookie.
    const actuel = cfg.comptes.find((c) => c.identifiant === s.identifiant);
    if (!actuel) return null;
    return {
      identifiant: actuel.identifiant,
      nom: actuel.nom,
      role: actuel.role,
      siteId: actuel.siteId,
      siteLabel: actuel.siteLabel,
    };
  } catch {
    // cookies() indisponible hors requête : silencieux.
    return null;
  }
}

/**
 * Garde serveur des espaces de colisage/réception : si l'authentification est
 * active, seuls les comptes 'france' passent. Retourne null si OK, sinon le
 * message d'erreur FR à renvoyer (HTTP 403).
 */
export async function exigerRoleFrance(): Promise<string | null> {
  const cfg = await lireConfigFichier();
  if (cfg.comptes.length === 0) return null; // auth désactivée
  const compte = await lireCompteRequete();
  if (!compte) {
    return "Connexion requise : identifiez-vous pour accéder à la réception et au colisage.";
  }
  if (compte.role !== "france") {
    return "Espace réservé au compte France (Clément Design). Les comptes façonniers gèrent la génération et l'impression des étiquettes.";
  }
  return null;
}
