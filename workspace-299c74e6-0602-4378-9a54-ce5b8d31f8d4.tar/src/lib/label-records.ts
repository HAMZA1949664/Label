/**
 * Persistance des étiquettes générées (mémoire permanente de la production).
 *
 * Chaque étiquette produite par l'application (.NLBL simple ou lot .zip) est
 * enregistrée en base : code-barres FAB (catalogue) ou SPE (calculé, préfixe
 * 99), OF, modèle, couleur, taille, manche. Cette mémoire sert :
 *  - au décodage colisage (le code SPE est relu en base, sans recalcul) ;
 *  - à la construction des réceptions prévues (semaine N imprimée par le
 *    façonnier → réception des pièces la semaine N+1).
 *
 * Chaque étiquette est également empilée pour le miroir cloud (Supabase,
 * base partagée entre la France et les façonniers) — voir src/lib/cloud/.
 *
 * Résolution canonique : les champs enregistrés sont recalculés depuis le
 * catalogue avec les MÊMES fonctions que le colisage (couleurLabel, taille-
 * Courte, mancheLabel, sleeveAbbrev) afin que les clés de regroupement soient
 * strictement identiques des deux côtés (attendu / reçu).
 */

import { db } from "@/lib/db";
import {
  couleurLabel,
  mancheLabel,
  sleeveAbbrev,
  speBarcode,
  tailleCourte,
} from "@/lib/label-data";
import { empilerSync } from "@/lib/cloud/queue";

/** Champs utiles d'une ligne catalogue pour la résolution. */
export interface LigneCatalogue {
  article: string;
  couleur: string; // code stock (BLC…)
  taille: string; // taille brute catalogue
  manche: string; // manche brute catalogue
  codeBarre: string;
}

/** Champs canoniques d'une étiquette enregistrée (modèle LabelRecord). */
export interface ChampsEtiquette {
  codeBarre: string;
  article: string;
  modele: string;
  couleur: string; // libellé FR
  couleurCode: string;
  taille: string; // compacte FR
  manche: string; // libellé FR ('' si sans objet)
  of: string;
  source: "FAB" | "SPE" | "EXT";
}

/** Entrée minimale d'une étiquette générée (7 variables du template). */
export interface EtiquetteGeneree {
  modele: string;
  type: string;
  of: string;
  codeBarre: string;
  couleur: string;
  manche: string;
  taille: string;
}

/** Construit le modèle complet comme le fait le colisage. */
export function modeleComplet(article: string, mancheBrute: string, spe: boolean): string {
  const abbrev = sleeveAbbrev(mancheBrute);
  return `${article}${abbrev ? ` ${abbrev}` : ""}${spe ? " SPE" : ""}`;
}

/** Champs canoniques depuis une ligne catalogue + OF. */
export function champsDepuisCatalogue(
  ligne: LigneCatalogue,
  of: string,
  spe: boolean
): ChampsEtiquette {
  return {
    codeBarre: ligne.codeBarre,
    article: ligne.article,
    modele: modeleComplet(ligne.article, ligne.manche, spe),
    couleur: couleurLabel(ligne.couleur)[0],
    couleurCode: ligne.couleur,
    taille: tailleCourte(ligne.taille)[0],
    manche: mancheLabel(ligne.manche)?.[0] ?? "",
    of: of ?? "",
    source: spe ? "SPE" : "FAB",
  };
}

/**
 * Repli « EXT » quand le catalogue ne permet plus de résoudre l'étiquette
 * (référence retirée du stock depuis la génération) : on conserve les
 * libellés affichés tels quels (partie française si bilingue).
 */
function champsDepuisAffichage(e: EtiquetteGeneree): ChampsEtiquette {
  const fr = (v: string) => (v.includes(" / ") ? v.split(" / ")[1] ?? v : v);
  const spe = / SPE$/i.test(e.modele.trim());
  return {
    codeBarre: e.codeBarre,
    article: e.modele.replace(/\s*SPE$/i, "").trim(),
    modele: e.modele,
    couleur: fr(e.couleur),
    couleurCode: "",
    taille: fr(e.taille),
    manche: fr(e.manche ?? ""),
    of: e.of ?? "",
    source: spe || e.codeBarre.startsWith("99") ? "SPE" : "EXT",
  };
}

/**
 * Résout une étiquette générée en champs canoniques :
 * 1. FAB — le code-barres existe dans le catalogue (EAN-13 stock) ;
 * 2. SPE — le code calculé speBarcode(article, couleur, manche, taille, OF)
 *    correspond à une ligne du catalogue (recherche inverse exacte) ;
 * 3. EXT — repli sur les libellés affichés.
 */
export function resoudreEtiquette(
  e: EtiquetteGeneree,
  fabParCode: Map<string, LigneCatalogue>,
  speParCode: Map<string, LigneCatalogue> | null
): ChampsEtiquette {
  const fab = fabParCode.get(e.codeBarre);
  if (fab) return champsDepuisCatalogue(fab, e.of, false);
  const spe = speParCode?.get(e.codeBarre);
  if (spe) return champsDepuisCatalogue(spe, e.of, true);
  return champsDepuisAffichage(e);
}

/**
 * Charge le catalogue en mémoire + l'index FAB par code-barres.
 * (4 623 lignes — requête unique, quelques millisecondes.)
 */
export async function chargerCatalogue(): Promise<{
  lignes: LigneCatalogue[];
  fabParCode: Map<string, LigneCatalogue>;
}> {
  const lignes = await db.article.findMany({
    select: { article: true, couleur: true, taille: true, manche: true, codeBarre: true },
  });
  const fabParCode = new Map<string, LigneCatalogue>();
  for (const l of lignes) fabParCode.set(l.codeBarre, l);
  return { lignes, fabParCode };
}

/**
 * Construit l'index inverse des codes SPE pour un OF donné :
 * code calculé → ligne catalogue. Utilisé pour la résolution inverse
 * (étiquette générée → référence exacte du stock).
 */
export function indexSpePourOf(
  lignes: LigneCatalogue[],
  of: string
): Map<string, LigneCatalogue> {
  const index = new Map<string, LigneCatalogue>();
  for (const l of lignes) {
    index.set(speBarcode(l.article, l.couleur, l.manche, l.taille, of), l);
  }
  return index;
}

/**
 * Enregistre en base l'ensemble des étiquettes d'une génération réussie
 * (appelé après production du .nlbl / .zip — n'interrompt jamais le
 * téléchargement : les erreurs sont journalisées côté serveur).
 */
export async function enregistrerEtiquettesGenerees(
  etiquettes: EtiquetteGeneree[],
  filename: string,
  quantites?: number[]
): Promise<number> {
  if (etiquettes.length === 0) return 0;
  try {
    const { lignes, fabParCode } = await chargerCatalogue();
    // Index SPE limité aux OF réellement présents dans le lot.
    const ofsDuLot = new Set(etiquettes.map((e) => e.of).filter(Boolean));
    const speParCode = new Map<string, LigneCatalogue>();
    for (const of of ofsDuLot) {
      for (const [code, ligne] of indexSpePourOf(lignes, of)) {
        if (!speParCode.has(code)) speParCode.set(code, ligne);
      }
    }
    const genereAt = new Date().toISOString();
    const records = etiquettes.map((e, i) => {
      const champs = resoudreEtiquette(e, fabParCode, speParCode);
      const q = quantites?.[i];
      return {
        // Identifiant explicite : repris comme local_id dans le cloud pour
        // une synchronisation idempotente (aucun doublon lors des rejeux).
        id: crypto.randomUUID(),
        codeBarre: champs.codeBarre,
        article: champs.article,
        modele: champs.modele,
        couleur: champs.couleur,
        couleurCode: champs.couleurCode,
        taille: champs.taille,
        manche: champs.manche,
        of: champs.of,
        type: e.type,
        source: champs.source,
        quantite: typeof q === "number" && Number.isInteger(q) && q >= 1 ? q : 1,
        filename,
      };
    });
    await db.labelRecord.createMany({ data: records });

    // Miroir cloud (Supabase) : chaque étiquette générée — code FAB du stock
    // ou SPE calculé — est poussée vers la base partagée (file d'attente :
    // jamais bloquant, reprise automatique en cas de coupure Internet).
    void empilerSync(
      "label_generations",
      records.map((r) => ({
        local_id: r.id,
        code_barre: r.codeBarre,
        article: r.article,
        modele: r.modele,
        couleur: r.couleur,
        couleur_code: r.couleurCode,
        taille: r.taille,
        manche: r.manche,
        of: r.of,
        type: r.type,
        source: r.source,
        quantite: r.quantite,
        filename: r.filename,
        genere_at: genereAt,
      }))
    );

    return records.length;
  } catch (error) {
    console.error("Persistance des étiquettes générées impossible :", error);
    return 0;
  }
}

// ---------------------------------------------------------------------------
// Index SPE global (codes recalculés) — partagé colisage / réceptions.
// ---------------------------------------------------------------------------

/** Référence résolue pour un code SPE : ligne catalogue + OF du calcul. */
export interface RefSpe {
  ref: LigneCatalogue;
  of: string;
}

const cacheSpeParOf = new Map<string, Map<string, LigneCatalogue>>();
let versionCatalogueCache = "";

function versionCatalogue(
  premier: string | undefined,
  dernier: string | undefined,
  total: number
): string {
  return `${total}:${premier ?? ""}:${dernier ?? ""}`;
}

/** Nombre maximal d'OF candidats pour le recalcul des codes SPE. */
export const MAX_OFS_CANDIDATS = 400;

/**
 * Reconstitue les candidats d'OF pour le décodage des codes SPE :
 * - les OF déjà journalisés par l'application (générations antérieures),
 * - les OF fournis par l'opérateur avec le lot scanné (facultatif).
 */
export async function candidatsOfs(ofsSaisis: string[]): Promise<string[]> {
  const ensemble = new Set<string>();
  for (const of of ofsSaisis) {
    const o = of.trim();
    if (/^\d{1,20}$/.test(o)) ensemble.add(o);
  }
  try {
    const journaux = await db.generationLog.findMany({
      select: { details: true },
      orderBy: { createdAt: "desc" },
      take: 300,
    });
    for (const j of journaux) {
      if (!j.details) continue;
      try {
        const details = JSON.parse(j.details) as {
          etiquettes?: Array<{ of?: unknown }>;
        };
        if (Array.isArray(details.etiquettes)) {
          for (const e of details.etiquettes) {
            if (typeof e.of === "string" && /^\d{1,20}$/.test(e.of.trim())) {
              ensemble.add(e.of.trim());
            }
          }
        }
      } catch {
        // détail illisible : on ignore cette entrée de journal
      }
    }
  } catch (error) {
    console.error("Lecture du journal pour le décodage SPE impossible :", error);
  }
  return [...ensemble].slice(0, MAX_OFS_CANDIDATS);
}

/**
 * Construit (avec cache mémoire versionné par le catalogue) l'index global
 * des codes SPE recalculés : code → { ligne catalogue, OF }.
 * Utilisé en repli quand un code scanné n'est ni FAB ni présent dans la
 * mémoire des étiquettes générées (LabelRecord).
 */
export async function construireIndexSpeGlobal(
  lignes: LigneCatalogue[],
  ofsSaisis: string[]
): Promise<Map<string, RefSpe>> {
  const version = versionCatalogue(
    lignes[0]?.codeBarre,
    lignes[lignes.length - 1]?.codeBarre,
    lignes.length
  );
  if (version !== versionCatalogueCache) {
    cacheSpeParOf.clear();
    versionCatalogueCache = version;
  }
  const ofs = await candidatsOfs(ofsSaisis);
  const speIndexGlobal = new Map<string, RefSpe>();
  for (const of of ofs) {
    let index = cacheSpeParOf.get(of);
    if (!index) {
      index = indexSpePourOf(lignes, of);
      cacheSpeParOf.set(of, index);
    }
    for (const [code, ref] of index) {
      // Un même code SPE désigne une seule combinaison par OF ;
      // première occurrence conservée (ordre déterministe du catalogue).
      if (!speIndexGlobal.has(code)) speIndexGlobal.set(code, { ref, of });
    }
  }
  return speIndexGlobal;
}
