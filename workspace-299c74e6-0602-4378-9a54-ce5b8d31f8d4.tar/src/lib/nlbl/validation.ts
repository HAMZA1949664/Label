/**
 * Validation des données d'étiquette avant génération du fichier .nlbl.
 *
 * Règles appliquées :
 * - champs obligatoires (Manche tolère une valeur vide : certaines références
 *   n'ont pas de manche, le texte reste simplement blanc sur l'étiquette) ;
 * - longueurs maximales généreuses alignées sur le design de l'étiquette ;
 * - code-barres EAN-13 : 13 chiffres + chiffre de contrôle obligatoire ;
 * - suppression des caractères de contrôle interdits en XML 1.0 ;
 * - échappement XML (&, <, >, ", ') ;
 * - encodage UTF-8 (accents gérés nativement par Zebra Designer).
 */

/** Données d'une étiquette, exactement les 7 variables du template .nlbl. */
export interface LabelInput {
  /** Modèle complet, ex. « SFAX MC » */
  modele: string;
  /** Type produit bilingue, ex. « Veste / Jacket » */
  type: string;
  /** Numéro d'ordre de fabrication, ex. « 078594 » */
  of: string;
  /** Code-barres EAN-13 (13 chiffres, clé incluse) */
  codeBarre: string;
  /** Couleur, ex. « Noir » */
  couleur: string;
  /** Manche bilingue, ex. « Manches courtes / Short sleeves » (peut être vide) */
  manche: string;
  /** Taille compacte, ex. « T3-S3 » */
  taille: string;
}

export interface FieldError {
  /** Index de l'étiquette dans le lot (0 = étiquette courante unique). */
  index: number;
  /** Nom du champ concerné. */
  champ: string;
  /** Message d'erreur en français. */
  message: string;
}

/** Longueurs maximales par champ. */
export const LIMITES = {
  modele: 40,
  type: 60,
  of: 20,
  codeBarre: 13,
  couleur: 40,
  manche: 60,
  taille: 20,
} as const;

/** Quantité maximale d'étiquettes par génération (lot .zip). */
export const MAX_ETIQUETTES = 100;

/** Longueur maximale du nom d'imprimante injecté dans le .nlbl. */
export const LIMITE_IMPRIMANTE = 64;

/** Caractères de contrôle interdits (hors tabulation acceptée puis nettoyée). */
const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

/** Échappe les 5 caractères spéciaux XML. */
export function xmlEscape(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Supprime les caractères de contrôle interdits et normalise les espaces extrêmes. */
export function nettoyer(value: unknown): string {
  if (typeof value !== "string") return "";
  return value.replace(CONTROL_CHARS, "").replace(/\r\n/g, "\n").trim();
}

/** Vérifie la clé de contrôle d'un code EAN-13 (13 chiffres). */
export function ean13Valide(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  const digits = code.split("").map(Number);
  const sum = digits
    .slice(0, 12)
    .reduce((acc, d, i) => acc + d * (i % 2 === 0 ? 1 : 3), 0);
  return (10 - (sum % 10)) % 10 === digits[12];
}

/**
 * Nettoie puis valide le nom d'imprimante optionnel (préférences utilisateur).
 * - undefined/null/chaîne vide → aucune modification (imprimante du template) ;
 * - erreur explicite si le type est incorrect ou la longueur dépassée.
 * Le nom sera ensuite échappé XML par le générateur (patcherImprimante).
 */
export function validerImprimante(raw: unknown): { nom?: string; erreur?: string } {
  if (raw === undefined || raw === null) return {};
  if (typeof raw !== "string") {
    return { erreur: "Le nom d'imprimante doit être une chaîne de caractères." };
  }
  // Les noms d'imprimante sont de simples noms de périphérique : les espaces
  // internes (tabulations, retours à la ligne…) sont normalisés en espaces.
  const nom = nettoyer(raw).replace(/\s+/g, " ");
  if (nom.length === 0) return {};
  if (nom.length > LIMITE_IMPRIMANTE) {
    return {
      erreur: `Nom d'imprimante trop long (max ${LIMITE_IMPRIMANTE} caractères).`,
    };
  }
  return { nom };
}

/**
 * Nettoie puis valide une liste d'étiquettes.
 * Retourne les étiquettes normalisées et la liste des erreurs (vide = OK).
 */
export function validerEtiquettes(inputs: unknown): {
  etiquettes: LabelInput[];
  erreurs: FieldError[];
} {
  const erreurs: FieldError[] = [];
  const etiquettes: LabelInput[] = [];

  if (!Array.isArray(inputs) || inputs.length === 0) {
    return { etiquettes: [], erreurs: [{ index: 0, champ: "lot", message: "Aucune donnée d'étiquette fournie." }] };
  }
  if (inputs.length > MAX_ETIQUETTES) {
    return {
      etiquettes: [],
      erreurs: [
        {
          index: 0,
          champ: "lot",
          message: `Trop d'étiquettes demandées (${inputs.length}). Maximum : ${MAX_ETIQUETTES}.`,
        },
      ],
    };
  }

  inputs.forEach((raw, index) => {
    const candidat = (raw ?? {}) as Record<string, unknown>;
    const etiquette: LabelInput = {
      modele: nettoyer(candidat.modele),
      type: nettoyer(candidat.type),
      of: nettoyer(candidat.of),
      codeBarre: nettoyer(candidat.codeBarre),
      couleur: nettoyer(candidat.couleur),
      manche: nettoyer(candidat.manche),
      taille: nettoyer(candidat.taille),
    };

    const verifs: Array<[keyof LabelInput, boolean, string]> = [
      ["modele", etiquette.modele.length > 0, "Le modèle est obligatoire."],
      ["modele", etiquette.modele.length <= LIMITES.modele, `Modèle trop long (max ${LIMITES.modele} caractères).`],
      ["type", etiquette.type.length > 0, "Le type de produit est obligatoire."],
      ["type", etiquette.type.length <= LIMITES.type, `Type trop long (max ${LIMITES.type} caractères).`],
      ["of", etiquette.of.length > 0, "Le numéro d'OF est obligatoire."],
      ["of", etiquette.of.length <= LIMITES.of, `OF trop long (max ${LIMITES.of} caractères).`],
      ["codeBarre", /^\d{13}$/.test(etiquette.codeBarre), "Le code-barres doit contenir exactement 13 chiffres."],
      ["codeBarre", ean13Valide(etiquette.codeBarre), "Clé de contrôle EAN-13 invalide."],
      ["couleur", etiquette.couleur.length > 0, "La couleur est obligatoire."],
      ["couleur", etiquette.couleur.length <= LIMITES.couleur, `Couleur trop longue (max ${LIMITES.couleur} caractères).`],
      ["manche", etiquette.manche.length <= LIMITES.manche, `Manche trop longue (max ${LIMITES.manche} caractères).`],
      ["taille", etiquette.taille.length > 0, "La taille est obligatoire."],
      ["taille", etiquette.taille.length <= LIMITES.taille, `Taille trop longue (max ${LIMITES.taille} caractères).`],
    ];

    let ok = true;
    for (const [champ, valide, message] of verifs) {
      if (!valide) {
        erreurs.push({ index, champ, message });
        ok = false;
      }
    }

    if (ok) etiquettes.push(etiquette);
  });

  return { etiquettes, erreurs };
}
