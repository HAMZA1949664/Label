/**
 * Réceptions prévues — types partagés client/serveur.
 *
 * Flux logistique : l'application génère et envoie les étiquettes au
 * façonnier (semaine N) ; les pièces correspondantes sont réceptionnées la
 * semaine N+1. Une « réception prévue » mémorise les lignes attendues
 * (OF → modèle → couleur → taille) et cumule les codes scannés pointés
 * dessus, session après session, pour comparer attendu / reçu / écart.
 */

/** Une ligne attendue, avec son état de réception calculé. */
export interface LigneEtatReception {
  id: string;
  of: string;
  modele: string;
  couleur: string;
  couleurCode: string;
  taille: string;
  manche: string;
  /** Quantité prévue (étiquettes générées, copies comprises). */
  attendu: number;
  /** Quantité réceptionnée (codes scannés attribués à cette ligne). */
  recu: number;
  /** Écart reçu − attendu (négatif = manquant, positif = excédent). */
  ecart: number;
  /** 'complet' | 'partiel' | 'zero' | 'excedent' */
  statut: "complet" | "partiel" | "zero" | "excedent";
}

/** Code reconnaissable mais dont la ligne n'est pas prévue dans la réception. */
export interface HorsPrevueItem {
  code: string;
  quantite: number;
  /** Modèle résolu (info affichée à l'opérateur). */
  modele: string;
}

/** Code illisible ou inconnu pointé sur la réception. */
export interface InconnuItem {
  code: string;
  quantite: number;
}

/** État complet d'une réception (détail + pointage). */
export interface EtatReception {
  reception: {
    id: string;
    titre: string;
    statut: string;
    note: string | null;
    createdAt: string;
    clotureAt: string | null;
  };
  lignes: LigneEtatReception[];
  horsPrevue: HorsPrevueItem[];
  inconnus: InconnuItem[];
  resume: {
    attenduTotal: number;
    /** Pièces attribuées aux lignes prévues. */
    recuTotal: number;
    /** Tous les codes pointés (y compris hors prévue / inconnus). */
    pointeTotal: number;
    lignesTotal: number;
    lignesCompletes: number;
    lignesPartielles: number;
    lignesZero: number;
    /** Taux de réception des lignes prévues, en % (arrondi). */
    tauxPct: number;
    horsPrevueQuantite: number;
    inconnusQuantite: number;
  };
}

/** Résumé d'une réception pour la liste déroulante. */
export interface ResumeReception {
  id: string;
  titre: string;
  statut: string;
  createdAt: string;
  lignesTotal: number;
  attenduTotal: number;
  recuTotal: number;
  /** Taux de réception en % (arrondi). */
  tauxPct: number;
}

/** Source de création d'une réception. */
export type SourceReception =
  | { mode: "of"; ofs: string[] }
  | { mode: "periode"; du: string; au: string } // jours AAAA-MM-JJ (Paris)
  | { mode: "tout" };

/** Corps de POST /api/receptions. */
export interface CorpsCreationReception {
  titre: string;
  note?: string;
  source: SourceReception;
}

/** Limite de sécurité : nombre maximal de lignes attendues par réception. */
export const MAX_LIGNES_RECEPTION = 2000;
