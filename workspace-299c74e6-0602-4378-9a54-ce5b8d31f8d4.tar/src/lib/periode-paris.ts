/**
 * Bornes temporelles en fuseau Europe/Paris pour le filtre par dates du journal.
 *
 * Le serveur raisonne en UTC (Prisma/SQLite) alors que l'utilisateur raisonne
 * en jours calendaires parisiens : ce module convertit un jour « AAAA-MM-JJ »
 * en l'instant UTC exact du minuit parisien correspondant (gestion du changement
 * d'heure été/hiver via Intl).
 */

/** Format de jour attendu : AAAA-MM-JJ. */
const RE_JOUR = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Convertit un jour calendaire « AAAA-MM-JJ » en l'instant UTC du minuit
 * Europe/Paris de ce jour. Retourne null si le format ou la date est invalide.
 */
export function debutJourParis(jour: string): Date | null {
  if (!RE_JOUR.test(jour)) return null;
  const base = new Date(`${jour}T00:00:00Z`);
  if (Number.isNaN(base.getTime())) return null;
  // Décalage horaire de Paris à cet instant : on formate le repère UTC en
  // heure parisienne, puis on compare les deux horloges.
  const parts = new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(base);
  const o = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  const heure = Number(o.hour) % 24; // certaines ICU notent minuit « 24 »
  const asUTC = Date.UTC(
    Number(o.year),
    Number(o.month) - 1,
    Number(o.day),
    heure,
    Number(o.minute),
    Number(o.second)
  );
  return new Date(base.getTime() - (asUTC - base.getTime()));
}

/** Résultat de l'analyse des paramètres de période d'une requête. */
export interface BornesPeriode {
  /** Clause Prisma sur createdAt (bornes incluses/exclusives). */
  where?: { createdAt: { gte?: Date; lt?: Date } };
  /** Message d'erreur FR si un paramètre est invalide. */
  erreur?: string;
}

/**
 * Analyse les paramètres de requête `depuis` et `jusqua` (jours AAAA-MM-JJ,
 * interprétés en Europe/Paris) et construit la clause Prisma correspondante :
 * - `depuis` → createdAt >= minuit Paris du jour ;
 * - `jusqua` → createdAt < minuit Paris du lendemain (borne exclusive, la
 *   journée complète est couverte).
 * Absence des deux paramètres → aucun filtre. Erreur FR si format incohérent
 * ou période inversée.
 */
export function analyserPeriode(url: URL): BornesPeriode {
  const depuis = url.searchParams.get("depuis");
  const jusqua = url.searchParams.get("jusqua");
  if (!depuis && !jusqua) return {};

  const createdAt: { gte?: Date; lt?: Date } = {};

  if (depuis) {
    const debut = debutJourParis(depuis);
    if (!debut) {
      return { erreur: "Date de début invalide (format attendu : AAAA-MM-JJ)." };
    }
    createdAt.gte = debut;
  }

  if (jusqua) {
    const fin = debutJourParis(jusqua);
    if (!fin) {
      return { erreur: "Date de fin invalide (format attendu : AAAA-MM-JJ)." };
    }
    fin.setUTCDate(fin.getUTCDate() + 1); // exclusif : début du lendemain
    createdAt.lt = fin;
  }

  if (createdAt.gte && createdAt.lt && createdAt.gte >= createdAt.lt) {
    return { erreur: "La date de début doit précéder la date de fin." };
  }

  return { where: { createdAt } };
}
