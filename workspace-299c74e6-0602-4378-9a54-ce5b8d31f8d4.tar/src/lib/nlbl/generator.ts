/**
 * Générateur de fichier .nlbl pour Zebra Designer 3 (Essentials).
 *
 * Principe (approche « données intégrées ») :
 * 1. Chargement du template cLEMENT2 (XML étiquette + XML solution) stocké dans
 *    src/lib/nlbl/templates/ — le design n'est JAMAIS modifié (polices, positions,
 *    tailles, paramètres de codes-barres restent identiques octet pour octet) ;
 * 2. Injection des valeurs des 7 variables (Modele, Type, OF, CodeBarre, Couleur,
 *    Manche, Taille) dans les blocs <DefaultValue> et <SampleValue> du .slnx :
 *    à l'ouverture dans Zebra Designer, les données sont déjà présentes —
 *    aucun import manuel n'est nécessaire ;
 * 3. Ré-encodage en archive ZIP chiffrée AES-256 (WinZip AE-1) avec le mot de
 *    passe fixe du format .nlbl, structure d'entrées identique à un
 *    enregistrement natif Zebra Designer : Formats/<nom> + <nom>.slnx.
 *
 * Lot de plusieurs étiquettes : Zebra Designer Essentials ne gérant qu'un jeu de
 * valeurs par étiquette (variables « saisie clavier », pas de connexion base de
 * données dans la version gratuite), un lot de N étiquettes distinctes est livré
 * dans un .zip contenant un .nlbl par étiquette.
 */

import { readFileSync } from "fs";
import { join } from "path";
import { buildZip, type ZipEntryInput } from "./zip-aes";
import { xmlEscape, type LabelInput } from "./validation";

/** Mot de passe fixe utilisé par Zebra Designer 3 pour chiffrer les .nlbl. */
export const NLBL_PASSWORD = ",^_A5Fus&!?j='Epiq*e";

/** Imprimante d'origine du template (conservée si aucune préférence utilisateur). */
export const IMPRIMANTE_DEFAUT = "ZDesigner GK420d";

/** Options optionnelles de génération (préférences utilisateur). */
export interface OptionsNlbl {
  /** Nom d'imprimante cible (remplace celui du template, sans toucher au design). */
  imprimante?: string;
  /** Copies à imprimer par étiquette du lot (1 par défaut, 1-99, aligné sur la liste). */
  quantites?: number[];
}

/** Nom interne du template (étiquette de référence). */
const TEMPLATE_NAME = "cLEMENT2";

const TEMPLATES_DIR = join(process.cwd(), "src", "lib", "nlbl", "templates");

function chargerTemplateEtiquette(): string {
  return readFileSync(join(TEMPLATES_DIR, "cLEMENT2_label.xml"), "utf-8");
}
function chargerTemplateSolution(): string {
  return readFileSync(join(TEMPLATES_DIR, "cLEMENT2_solution.slnx.xml"), "utf-8");
}

// ---------------------------------------------------------------------------
// Écriture des valeurs de variables (avec Base64 si caractères de contrôle)
// ---------------------------------------------------------------------------

/** Échappement + encodage Base64 si la valeur contient des caractères de contrôle. */
function encodervaleur(value: string): string {
  if (/[\r\n\t\u0000-\u001F]/.test(value)) {
    return Buffer.from(value, "utf-8").toString("base64");
  }
  return xmlEscape(value);
}

/** Construit un bloc <StringValue>/<UserValue> fidèle à l'indentation du template. */
function blocStringContents(tag: string, value: string, indentation: string): string {
  const b64 = /[\r\n\t\u0000-\u001F]/.test(value);
  const attr = b64 ? ' Base64Encoded="true"' : "";
  const contenu = encodervaleur(value);
  return (
    `<${tag} Type="StringContents">\n` +
    `${indentation}<StringValue${attr}>${contenu}</StringValue>\n` +
    `${indentation}<UserValue${attr}>${contenu}</UserValue>\n` +
    `      </${tag}>`
  );
}

/**
 * Remplace les blocs <DefaultValue> et <SampleValue> d'une variable donnée
 * dans le XML solution. Le bloc est repéré par <Name>nomVariable</Name>.
 */
function patcherVariable(xml: string, nomVariable: string, valeur: string): string {
  const regex = /<Item Type="Variable">[\s\S]*?<\/Item>/g;

  return xml.replace(regex, (bloc) => {
    if (!bloc.includes(`<Name>${nomVariable}</Name>`)) return bloc;

    let nouveau = bloc;
    const defaut = blocStringContents("DefaultValue", valeur, "        ");
    nouveau = nouveau.replace(
      /<DefaultValue Type="StringContents">[\s\S]*?<\/DefaultValue>/,
      () => defaut
    );
    const sample = blocStringContents("SampleValue", valeur, "        ");
    nouveau = nouveau.replace(
      /<SampleValue Type="StringContents">[\s\S]*?<\/SampleValue>/,
      () => sample
    );
    return nouveau;
  });
}

/** Renomme la solution/étiquette (nom affiché dans Zebra Designer). */
function renommer(xml: string, nouveauNom: string): string {
  return xml
    .split(`<Name>${TEMPLATE_NAME}</Name>`)
    .join(`<Name>${xmlEscape(nouveauNom)}</Name>`)
    .split(`<SolutionName>${TEMPLATE_NAME}</SolutionName>`)
    .join(`<SolutionName>${xmlEscape(nouveauNom)}</SolutionName>`);
}

/**
 * Remplace l'imprimante cible dans le XML étiquette (bloc <Printer>).
 * Le DESIGN n'est PAS modifié (polices, positions, tailles, codes-barres) :
 * seuls <Name>, <DriverName> et le nom contenu dans le DevModeBuffer sont
 * remplacés, à longueur d'octets identique — la structure DEVMODEW reste
 * conforme (aucun décalage).
 *
 * DevModeBuffer (structure DEVMODEW sérialisée en base64) :
 * - dmDeviceName (champ WCHAR[32] = 64 octets en tête de buffer) : nom
 *   UTF-16LE terminé par des octets nuls, remplacé sur les 64 octets complets
 *   (noms jusqu'à 32 caractères) ;
 * - occurrences ANSI du nom dans les données driver additionnelles
 *   (dmDriverExtra) : remplacées à longueur d'octets égale (tronquées à
 *   16 caractères, complétées par des octets nuls).
 */
function patcherImprimante(xml: string, nomImprimante: string): string {
  return xml.replace(
    /<Printer Type="Printer">[\s\S]*?<\/Printer>/,
    (bloc) =>
      bloc
        .replace(
          /<Name>[^<]*<\/Name>/,
          `<Name>${xmlEscape(nomImprimante)}</Name>`
        )
        .replace(
          /<DriverName>[^<]*<\/DriverName>/,
          `<DriverName>${xmlEscape(nomImprimante)}</DriverName>`
        )
        .replace(/<DevModeBuffer>[^<]*<\/DevModeBuffer>/, (bloc64) => {
          const ancienWchar = Buffer.from(IMPRIMANTE_DEFAUT, "utf16le"); // 32 octets
          const ancienChamp = Buffer.concat([
            ancienWchar,
            Buffer.alloc(64 - ancienWchar.length, 0), // fin du champ WCHAR[32]
          ]);
          const ancienAnsi = Buffer.from(IMPRIMANTE_DEFAUT, "latin1"); // 16 octets

          const buffer = Buffer.from(
            bloc64.slice(
              "<DevModeBuffer>".length,
              bloc64.length - "</DevModeBuffer>".length
            ),
            "base64"
          );

          // 1. dmDeviceName complet (WCHAR[32] : nom + octets nuls) → nom
          //    tronqué à 32 caractères + complétion nulle sur 64 octets.
          const positionChamp = buffer.indexOf(ancienChamp);
          if (positionChamp !== -1) {
            const nouveauWchar = Buffer.from(
              nomImprimante.slice(0, 32),
              "utf16le"
            );
            const champRemplace = Buffer.concat([
              nouveauWchar,
              Buffer.alloc(64 - nouveauWchar.length, 0),
            ]);
            champRemplace.copy(buffer, positionChamp);
          }

          // 2. Occurrences ANSI (données driver) → même longueur d'octets,
          //    nom tronqué à la taille du nom d'origine + octets nuls.
          const ansi = nomImprimante
            .slice(0, ancienAnsi.length)
            .normalize("NFKD")
            .replace(/[\u0300-\u036f]/g, ""); // ASCII approximate pour latin1
          const remplacementAnsi = Buffer.concat([
            Buffer.from(ansi, "latin1").subarray(0, ancienAnsi.length),
            Buffer.alloc(
              Math.max(0, ancienAnsi.length - Buffer.byteLength(ansi, "latin1")),
              0
            ),
          ]).subarray(0, ancienAnsi.length);
          let position = buffer.indexOf(ancienAnsi);
          while (position !== -1) {
            remplacementAnsi.copy(buffer, position);
            position = buffer.indexOf(ancienAnsi, position + ancienAnsi.length);
          }

          return `<DevModeBuffer>${buffer.toString("base64")}</DevModeBuffer>`;
        })
  );
}

// ---------------------------------------------------------------------------
// Assemblage .nlbl
// ---------------------------------------------------------------------------

/** Correspondance nom de variable du template → champ des données. */
const CHAMPS_VARIABLES: Array<[string, keyof LabelInput]> = [
  ["Modele", "modele"],
  ["Type", "type"],
  ["OF", "of"],
  ["CodeBarre", "codeBarre"],
  ["Couleur", "couleur"],
  ["Manche", "manche"],
  ["Taille", "taille"],
];

/**
 * Construit les deux XML (étiquette + solution) prêts à être archivés.
 * Exporté pour la vérification croisée (scripts/verifier-nlbl.ts) et l'aperçu.
 */
export function construireXmlsNlbl(
  etiquette: LabelInput,
  nomInterne: string,
  options: OptionsNlbl = {}
): { solution: string; format: string } {
  let solution = renommer(chargerTemplateSolution(), nomInterne);
  let format = renommer(chargerTemplateEtiquette(), nomInterne);

  // Préférences imprimante : réglages uniquement, le design reste intact
  if (options.imprimante) {
    format = patcherImprimante(format, options.imprimante);
  }

  for (const [nomVariable, champ] of CHAMPS_VARIABLES) {
    solution = patcherVariable(solution, nomVariable, etiquette[champ]);
  }

  return { solution, format };
}

/**
 * Construit le contenu binaire d'un fichier .nlbl (ZIP AES) pour une étiquette.
 * @param etiquette données validées
 * @param nomInterne nom affiché dans Zebra Designer (ASCII, sans extension)
 * @param options options de génération (imprimante cible, …)
 */
export function construireNlbl(
  etiquette: LabelInput,
  nomInterne: string,
  options: OptionsNlbl = {}
): Buffer {
  const { solution, format } = construireXmlsNlbl(etiquette, nomInterne, options);

  const entrees: ZipEntryInput[] = [
    {
      name: `Formats/${nomInterne}`,
      data: Buffer.from(format, "utf-8"),
      modified: new Date(),
      aes: { password: NLBL_PASSWORD, strength: 3 },
    },
    {
      name: `${nomInterne}.slnx`,
      data: Buffer.from(solution, "utf-8"),
      modified: new Date(),
      aes: { password: NLBL_PASSWORD, strength: 3 },
    },
  ];

  return buildZip(entrees);
}

// ---------------------------------------------------------------------------
// Aperçu structuré (prévisualisation du contenu sans téléchargement)
// ---------------------------------------------------------------------------

/** Aperçu structuré d'un .nlbl, tel qu'il serait généré. */
export interface ApercuNlbl {
  /** Nom interne de la solution/étiquette dans l'archive. */
  nomInterne: string;
  /** Entrées de l'archive ZIP. */
  entrees: string[];
  /** Description du chiffrement. */
  chiffrement: string;
  /** Imprimante cible intégrée au fichier. */
  imprimante: string;
  /** Les 7 variables injectées (ordre du template). */
  variables: Array<{ nom: string; valeur: string }>;
  /** XML solution complet, valeurs intégrées. */
  xmlSolution: string;
  /** Taille réelle du fichier .nlbl qui serait téléchargé (octets). */
  tailleOctets: number;
}

/**
 * Construit l'aperçu structuré d'un .nlbl (sans journalisation ni téléchargement).
 * Utilisé par l'API de prévisualisation « Contenu du fichier ».
 */
export function apercuNlbl(
  etiquette: LabelInput,
  nomInterne: string,
  options: OptionsNlbl = {}
): ApercuNlbl {
  const { solution } = construireXmlsNlbl(etiquette, nomInterne, options);
  return {
    nomInterne,
    entrees: [`Formats/${nomInterne}`, `${nomInterne}.slnx`],
    chiffrement:
      "ZIP chiffré AES-256 (WinZip AE-1) — mot de passe natif Zebra Designer",
    imprimante: options.imprimante ?? IMPRIMANTE_DEFAUT,
    variables: CHAMPS_VARIABLES.map(([nom, champ]) => ({
      nom,
      valeur: etiquette[champ],
    })),
    xmlSolution: solution,
    tailleOctets: construireNlbl(etiquette, nomInterne, options).length,
  };
}

// ---------------------------------------------------------------------------
// Horodatage du nom de fichier (fuseau Europe/Paris)
// ---------------------------------------------------------------------------

export function horodatageFichier(d: Date = new Date()): string {
  const fmt = new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
  const p = fmt.formatToParts(d);
  const get = (t: string) => p.find((x) => x.type === t)?.value ?? "";
  return `${get("year")}${get("month")}${get("day")}_${get("hour")}${get("minute")}`;
}

/** Transforme un texte en segment de nom de fichier sûr (ASCII, sans espace). */
export function slug(texte: string, max = 28): string {
  return (
    texte
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // retire les accents
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, max)
      .replace(/-+$/g, "") || "etiquette"
  );
}

const LISEZMOI = `ÉTIQUETTES — LOT DE FICHIERS .NLBL (Zebra Designer Essentials 3)
=====================================================================

Ce lot contient un fichier .nlbl par étiquette, avec les données
DÉJÀ INTÉGRÉES : aucun import de fichier texte n'est nécessaire.

Pour imprimer chaque étiquette :
1. Ouvrir le fichier .nlbl souhaité dans Zebra Designer 3 ;
2. Cliquer sur « Imprimer » : les valeurs sont déjà remplies ;
3. Régler la quantité puis lancer l'impression.

Astuce : pour N copies de la MÊME étiquette, un seul fichier suffit —
régler « Nombre d'étiquettes » dans la fenêtre d'impression de Zebra Designer.

Ce fichier a été généré automatiquement par l'application
Étiquettes & colisage de Clément Design.
`;

/**
 * LISEZMOI enrichi des quantités demandées (une par fichier du lot, dans
 * l'ordre). Les quantités ne multiplient pas les fichiers : chaque étiquette
 * distincte reste un unique .nlbl, et la quantité indique combien de copies
 * imprimer via « Nombre d'étiquettes » dans Zebra Designer.
 */
function construireLisezMoi(nomsFichiers: string[], quantites?: number[]): string {
  if (!quantites || quantites.length !== nomsFichiers.length || quantites.every((q) => q === 1)) {
    return LISEZMOI;
  }
  const lignes = nomsFichiers
    .map(
      (nom, i) =>
        `- ${nom} : imprimer ×${quantites[i]} copie${quantites[i] > 1 ? "s" : ""}`
    )
    .join("\n");
  const total = quantites.reduce((s, q) => s + q, 0);
  return (
    LISEZMOI +
    `\nQUANTITÉS DEMANDÉES (total : ${total} copies) — réglez « Nombre ` +
    `d'étiquettes » dans Zebra Designer pour chaque fichier :\n\n${lignes}\n`
  );
}

// ---------------------------------------------------------------------------
// Paquet final : 1 étiquette → .nlbl direct ; N étiquettes → .zip
// ---------------------------------------------------------------------------

export interface PaquetNlbl {
  /** Nom de fichier proposé au téléchargement. */
  filename: string;
  /** Type MIME. */
  mime: string;
  /** Contenu binaire. */
  data: Buffer;
  /** Nombre de fichiers .nlbl contenus (étiquettes distinctes). */
  labelCount: number;
  /** Nombre total de copies demandées (somme des quantités, ≥ labelCount). */
  copiesTotales: number;
  /** Mode de livraison : « nlbl » (fichier unique) ou « zip » (lot). */
  mode: "nlbl" | "zip";
}

/** Quantité par défaut (1 copie) pour chaque étiquette du lot. */
function quantitesNormalisees(nb: number, quantites?: number[]): number[] {
  if (!quantites || quantites.length !== nb) {
    return Array.from({ length: nb }, () => 1);
  }
  // Garde-fou : entier entre 1 et 99, défaut 1 si invalide
  return quantites.map((q) =>
    Number.isInteger(q) && q >= 1 && q <= 99 ? q : 1
  );
}

/**
 * Génère le paquet téléchargeable :
 * - 1 étiquette  → etiquettes_AAAAMMJJ_HHmm.nlbl
 * - N étiquettes → etiquettes_AAAAMMJJ_HHmm.zip (un .nlbl par étiquette)
 * - options.quantites : copies à imprimer par fichier (documentées dans le
 *   LISEZMOI du .zip ; les fichiers restent uniques par étiquette distincte)
 */
export function genererPaquetNlbl(
  etiquettes: LabelInput[],
  maintenant: Date = new Date(),
  options: OptionsNlbl = {}
): PaquetNlbl {
  if (etiquettes.length === 0) {
    throw new Error("Aucune étiquette à générer.");
  }

  const base = `etiquettes_${horodatageFichier(maintenant)}`;

  if (etiquettes.length === 1) {
    const data = construireNlbl(etiquettes[0], base, options);
    const quantite = quantitesNormalisees(1, options.quantites)[0];
    return {
      filename: `${base}.nlbl`,
      mime: "application/octet-stream",
      data,
      labelCount: 1,
      copiesTotales: quantite,
      mode: "nlbl",
    };
  }

  const quantites = quantitesNormalisees(etiquettes.length, options.quantites);

  const nomsFichiers = etiquettes.map((etiquette, i) => {
    const numero = String(i + 1).padStart(3, "0");
    return `etiquette_${numero}_${slug(etiquette.modele)}_OF${slug(etiquette.of, 12)}.nlbl`;
  });

  const entrees: ZipEntryInput[] = etiquettes.map((etiquette, i) => {
    const nom = nomsFichiers[i].replace(/\.nlbl$/, "");
    return {
      name: `${base}/${nomsFichiers[i]}`,
      data: construireNlbl(etiquette, nom, options),
      modified: maintenant,
    };
  });
  entrees.push({
    name: `${base}/LISEZMOI.txt`,
    data: Buffer.from(construireLisezMoi(nomsFichiers, quantites), "utf-8"),
    modified: maintenant,
  });

  return {
    filename: `${base}.zip`,
    mime: "application/zip",
    data: buildZip(entrees),
    labelCount: etiquettes.length,
    copiesTotales: quantites.reduce((s, q) => s + q, 0),
    mode: "zip",
  };
}
